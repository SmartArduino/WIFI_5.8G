/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define USE_CONSOLE_PORT            (1)

#define MQTT_TASK_STACK_SIZE        1024
#define MQTT_TASK_PRI               1

#define MQTT_MAX_MSG_SIZE           1024

#define CONSOLE_PORT                UART2
#define CONSOLE_BUFF_SIZE           256

#define MQTT_MAX_SOCK_FD            5

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    MQTT_TYPE_CONNECT,
    MQTT_TYPE_SEND
} MQTT_IND;

typedef enum
{
    MQTT_SM_CLI_INIT = 0,
    MQTT_SM_CLI_INPUT_AP_SSID,
    MQTT_SM_CLI_INPUT_AP_PASSWD,
    MQTT_SM_CLI_SET_PARAM,
    MQTT_SM_CLI_JOIN_AP,
    MQTT_SM_CLI_ASSOCIATION,
    MQTT_SM_CLI_CONN_AP,
    MQTT_SM_CLI_CONN_SERVER,
    MQTT_SM_CLI_MSG_PUB,
    MQTT_SM_CLI_END
} MQTT_CLI_SM_STATE;

enum
{
    MQTT_IDLE = 0,
    MQTT_CONNECTED_SERVER,
    MQTT_DISCONNECTED_SERVER,
    MQTT_MESSAGE_PUBLISHED      /* Only for Publisher */
};

enum
{
    MQTT_MIB_SERVER_IP = 0, // 0
    MQTT_MIB_PORT,          // 1
    MQTT_MIB_SUPP_SSL,      // 2
    MQTT_MIB_NA,            // 3
    MQTT_MIB_USER_NAME,     // 4
    MQTT_MIB_PASSWORD,      // 5
    MQTT_MIB_PUB_TOPIC,     // 6
    MQTT_MIB_SUB_TOPIC,     // 7
    MQTT_MIB_PUB_QOS,       // 8
    MQTT_MIB_SUB_QOS,       // 9
    MQTT_MIB_CLIENT_ID,     // 10
    MQTT_MIB_PERSISTENCE,   // 11
    MQTT_MIB_WILL_TOPIC,    // 12
    MQTT_MIB_WILL_MSG,      // 13
    MQTT_MIB_KEEPALIVE,     // 14
    MQTT_MIB_MAX_PARAM
};

typedef struct
{
    INT32   result;
    UINT32  rst_code;
    UINT32  err_code;    
} ICT_ST_MQTT_IND_T;

typedef struct
{
    UINT32  len;
    UINT8   buf[MQTT_MAX_MSG_SIZE];
} ICT_ST_MQTT_MSG_T;

typedef struct
{
    UINT32  len;
    UINT8   buf[CONSOLE_BUFF_SIZE];
} ICT_ST_CONS_DATA_T;

typedef struct
{
    INT32 ap_asso;
    INT32 ap_conn;

    INT32 pub_conn;
    INT32 sub_conn;

    ICT_ST_MQTT_IND_T   pub_ind;
    ICT_ST_MQTT_IND_T   sub_ind;

    char root_ca_file[128];
    char cert_file[128];
    char priv_key_file[128];
    
    UINT32 waiting_cnt;
    UINT8 host_ip[32];
    
    MQTT_CLI_SM_STATE   sm_state;

    T_NMS_MQTT_MIB      *p_mqtt_mib;
    ICT_ST_MQTT_MSG_T   sub_msg;

    ICT_ST_JOIN_REQ_T           join_req;
    ICT_ST_NETWORK_INFO_IND_T   network_info;    
} ICT_ST_MQTT_CNTX_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_mqtt_task = ICT_NULL;

static ICT_ST_CONS_DATA_T       cons_line_data;
static ICT_ST_MQTT_CNTX_T       mqtt_cntx;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

DWALIGN OS_STK mqtt_task_stack[MQTT_TASK_STACK_SIZE] XDWALIGN;
DWALIGN TN_EVENT uart_event_group XDWALIGN;

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void console_port_config(void)
{
    ict_api_uart_init(CONSOLE_PORT);
    ict_api_uart_open(CONSOLE_PORT);    
    ict_api_uart_change_baudrate (CONSOLE_PORT, 115200, fMACWLEN(UART_WORD_LEN_8BITS));
}

INT32 console_is_rx_empty(void)
{
    return ict_api_uart_is_rx_empty(CONSOLE_PORT);
}

UINT32 console_get_data(char *buf, UINT32 maxLen)
{
    return (UINT32)ict_api_uart_gets(CONSOLE_PORT, buf, maxLen);
}

UINT32 console_send_byte(char ch)
{
    return (UINT32)ict_api_uart2_putc(ch);
}

void console_send_data(UINT8 *buf, UINT32 len)
{
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, buf, len);
}

void console_printf (char *fmt,...)
{
	va_list             ap;
    char                str[128];
    int                 size;
    
    va_start(ap, fmt);
	size = xn_vsprintf (&str, fmt, ap);
    size &= (sizeof(str)-1);
    ict_api_uart_direct_send_w_size(CONSOLE_PORT, str, size);    
  	va_end (ap);
}

INT32 console_get_line(ICT_ST_CONS_DATA_T *p_data)
{
    char    cons_buf[CONSOLE_BUFF_SIZE];
    UINT32  cons_len = 0;
    UINT32  data_cnt = 0;
    char    ch;
    
    if(console_is_rx_empty())
    {
        return ICT_FALSE;
    }
    else
    {
        cons_len = console_get_data(cons_buf, sizeof(cons_buf));
    }
    
    while(cons_len > data_cnt)
    {
        ch = cons_buf[data_cnt++];
        
        if(ch == '\b')
        {            
            if(p_data->len)
            {
                p_data->len -= 1;
                p_data->buf[p_data->len] = '\0';
                console_printf("\b \b");                
            }
            continue;
        }
        
        if((ch == 0x0D) || (ch == 0x0A))
        {
            if(p_data->len)                
            {
                p_data->buf[p_data->len++] = '\0';
                return ICT_TRUE;
            }
            else
            {
                p_data->buf[0] = '\0';
                return ICT_TRUE;
            }
        }
        else
        {
            console_send_byte(ch);
            p_data->buf[p_data->len++] = ch;
        }
    }

    return ICT_FALSE;
}

void wlan_config(void)
{
    UINT8 ssid[MAX_SSID_LEN] = "NETGEAR19";
    UINT8 password[MAX_PSK_LEN] = "wifi1234";
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */    
    ICT_ST_MQTT_CNTX_T  *p_cntx;
    INT32 result;

    p_cntx = &mqtt_cntx;
    ICT_MEMSET(p_cntx, 0, sizeof(ICT_ST_MQTT_CNTX_T));

    p_cntx->ap_asso = ICT_FALSE;
    p_cntx->ap_conn = ICT_FALSE;
    
    ICT_MEMSET(&p_cntx->join_req, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    p_cntx->join_req.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(p_cntx->join_req.ssid, ssid);
    p_cntx->join_req.key_len = ICT_STRLEN(password);
    ICT_STRCPY(p_cntx->join_req.key, password);
    
    if (p_cntx->join_req.ssid_len) printf("ssid: %s\n", p_cntx->join_req.ssid);
    if (p_cntx->join_req.key_len) printf("pwd: %s\n", p_cntx->join_req.key);

    result = ict_api_join_handler(&p_cntx->join_req);
    printf("[%s] result: %d\n", __func__, result);
}

void mqtt_client_show_mib(T_NMS_MQTT_MIB *p_mib)
{
    printf("\n");
    printf("============================== MQTT MIB ==============================\n");
    printf("= [0]  svr_ip(or URL) : %s\n", p_mib->server_ip);
    printf("= [1]  port           : %d\n", p_mib->port);
    printf("= [2]  ssl            : %d\n", p_mib->ssl);
    printf("= [3]  N/A            : \n");
    printf("= [4]  user_name      : %s\n", p_mib->user_name);
    printf("= [5]  password       : %s\n", p_mib->password);
    printf("= [6]  pub_topic      : %s\n", p_mib->pub_topic);
    printf("= [7]  sub_topic      : %s\n", p_mib->sub_topic);
    printf("= [8]  pub_qos        : %d\n", p_mib->pub_qos);
    printf("= [9]  sub_qos        : %d\n", p_mib->sub_qos);
    printf("= [10] client_id      : %s\n", p_mib->client_id);
    printf("= [11] persistence    : %d\n", p_mib->persistence);
    printf("= [12] will_topic     : %s\n", p_mib->will_topic);
    printf("= [13] will_msg       : %s\n", p_mib->will_msg);
    printf("= [14] keepalive      : %d\n", p_mib->keepalive);
    printf("======================================================================\n\n");
    
#if USE_CONSOLE_PORT
    console_printf("\r\n=============================== MQTT MIB ==============================\r\n");
    console_printf("= [0]  svr_ip(or URL) : %s\r\n", p_mib->server_ip);
    console_printf("= [1]  port           : %d\r\n", p_mib->port);
    console_printf("= [2]  ssl            : %d\r\n", p_mib->ssl);
    console_printf("= [3]  N/A            : \r\n");
    console_printf("= [4]  user_name      : %s\r\n", p_mib->user_name);
    console_printf("= [5]  password       : %s\r\n", p_mib->password);
    console_printf("= [6]  pub_topic      : %s\r\n", p_mib->pub_topic);
    console_printf("= [7]  sub_topic      : %s\r\n", p_mib->sub_topic);
    console_printf("= [8]  pub_qos        : %d\r\n", p_mib->pub_qos);
    console_printf("= [9]  sub_qos        : %d\r\n", p_mib->sub_qos);
    console_printf("= [10] client_id      : %s\r\n", p_mib->client_id);
    console_printf("= [11] persistence    : %d\r\n", p_mib->persistence);
    console_printf("= [12] will_topic     : %s\r\n", p_mib->will_topic);
    console_printf("= [13] will_msg       : %s\r\n", p_mib->will_msg);
    console_printf("= [14] keepalive      : %d\r\n", p_mib->keepalive);
    console_printf("===========================================================================\r\n\r\n");
#endif    
}

void mqtt_client_set(void)
{
    char host[32];
    INT32 result;
    ICT_ST_MQTT_CNTX_T  *p_cntx;
    T_NMS_MQTT_MIB      *p_mib;

    char mqtt_str_buf[128];
    UINT32 mqtt_set_value;
    UINT32 mqtt_str_len = 0;
    INT32 mqtt_mib_set = ICT_FALSE;
    
    p_cntx = &mqtt_cntx;

    p_mib = ict_api_sta_mqtt_get();
    p_cntx->p_mqtt_mib = p_mib;

    ICT_STRCPY(mqtt_str_buf, "a3fg27jowxisph-ats.iot.ap-northeast-2.amazonaws.com");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->server_ip, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_SERVER_IP, mqtt_str_buf, mqtt_str_len);
        printf("= [0]  svr_ip(or URL) => %s\n", p_mib->server_ip);
    }

    ICT_STRCPY(mqtt_str_buf, "8883");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->port != mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_PORT, mqtt_str_buf, mqtt_str_len);
        printf("= [1]  port => %d\n", p_mib->port);
    }

    ICT_STRCPY(mqtt_str_buf, "4"); /* 0 :None / 1 :SSL3.0 / 2 :TLS1.0 / 3 :- / 4 :TSL1.2 */
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->ssl != mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_SUPP_SSL, mqtt_str_buf, mqtt_str_len);
        printf("= [2]  ssl => %d\n", p_mib->ssl);
    }

    ICT_STRCPY(mqtt_str_buf, "admin");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->user_name, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_USER_NAME, mqtt_str_buf, mqtt_str_len);
        printf("= [4]  user_name => %s\n", p_mib->user_name);
    }

    ICT_STRCPY(mqtt_str_buf, "admin");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->password, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_PASSWORD, mqtt_str_buf, mqtt_str_len);
        printf("= [5]  password => %s\n", p_mib->password);
    }

    ICT_STRCPY(mqtt_str_buf, "myTopic");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->pub_topic, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_PUB_TOPIC, mqtt_str_buf, mqtt_str_len);
        printf("= [6]  pub_topic => %s\n", p_mib->pub_topic);
    }

    ICT_STRCPY(mqtt_str_buf, "myTopic");
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->sub_topic, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_SUB_TOPIC, mqtt_str_buf, mqtt_str_len);
        printf("= [7]  sub_topic => %s\n", p_mib->sub_topic);
    }

    ICT_STRCPY(mqtt_str_buf, "1"); /* 0 ~ 2 */
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->pub_qos != mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_PUB_QOS, mqtt_str_buf, mqtt_str_len);
        printf("= [8]  pub_qos => %d\n", p_mib->pub_qos);
    }

    ICT_STRCPY(mqtt_str_buf, "1"); /* 0 ~ 2 */
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->sub_qos != mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_SUB_QOS, mqtt_str_buf, mqtt_str_len);
        printf("= [9]  sub_qos => %d\n", p_mib->sub_qos);
    }

    ICT_STRCPY(mqtt_str_buf, ""); /* If empty, use MAC address to client_id */
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->client_id, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_CLIENT_ID, mqtt_str_buf, mqtt_str_len);
        printf("= [10]  client_id => %s\n", p_mib->client_id);
    }

    ICT_STRCPY(mqtt_str_buf, "0"); /* 0 ~ 2 */
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->persistence!= mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_PERSISTENCE, mqtt_str_buf, mqtt_str_len);
        printf("= [11]  persistence => %d\n", p_mib->persistence);
    }

    ICT_STRCPY(mqtt_str_buf, ""); 
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->will_topic, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_WILL_TOPIC, mqtt_str_buf, mqtt_str_len);
        printf("= [12]  will_topic => %s\n", p_mib->will_topic);
    }

    ICT_STRCPY(mqtt_str_buf, ""); 
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    if(ICT_STRCMP(p_mib->will_msg, mqtt_str_buf) != 0)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_WILL_MSG, mqtt_str_buf, mqtt_str_len);
        printf("= [13]  will_msg => %s\n", p_mib->will_msg);
    }

    ICT_STRCPY(mqtt_str_buf, "0"); 
    mqtt_str_len = ICT_STRLEN(mqtt_str_buf);
    mqtt_str_buf[mqtt_str_len] = 0;
    mqtt_set_value = ICT_ATOI((char*)mqtt_str_buf);
    if(p_mib->keepalive!= mqtt_set_value)
    { 
        ict_api_sta_mqtt_set(MQTT_MIB_KEEPALIVE, mqtt_str_buf, mqtt_str_len);
        printf("= [14]  keepalive => %d\n", p_mib->keepalive);
    }

    mqtt_client_show_mib(p_mib);    

    ICT_STRCPY(p_cntx->root_ca_file, "ROOTCA.PEM");
    ICT_STRCPY(p_cntx->cert_file, "CERT.CRT");
    ICT_STRCPY(p_cntx->priv_key_file, "PRIVATE.KEY");    
    ict_api_sta_mqtt_cert_set(p_cntx->root_ca_file, p_cntx->cert_file, p_cntx->priv_key_file);
    
}

INT32 mqtt_client_event_ind(UINT8 *buf, UINT32 len, ICT_ST_MQTT_IND_T *ind)
{
    UINT8 str[2][64];
    UINT32  i = 0, j= 0, cnt = 0;
    INT32 rtn_val = ICT_TRUE;

    if(len == 0)
    {
        return ICT_FALSE;
    }

    for(cnt = 0; cnt < len; cnt++)
    {
        if((buf[cnt] == ' ') && (i == 0))
        {
            str[i][j] = 0;
            i = 1;
            j = 0;
        }
        else if((buf[cnt] == 0x0D) || (buf[cnt] == 0x0A))
        {
            str[i][j] = 0;
            break;
        }
        else
        {
            str[i][j++] = buf[cnt];
        }
    }

    if(ICT_STRCMP(str[0], "OK") == 0)
    {
        ind->result = ICT_TRUE;
        ind->rst_code = ICT_ATOI(str[1]);
        ind->err_code = 0;
    }
    else if(ICT_STRCMP(str[0], "ERROR") == 0)
    {
        ind->result = ICT_ERR;
        ind->rst_code = 0;
        ind->err_code = ICT_ATOI(str[1]);
    }
    else
    {
        rtn_val = ICT_FALSE;
    }

    return rtn_val;
}

INT32 mqtt_client_connect_with_server(void)
{
    return ict_api_mqtt_connect_handler(NULL, 0);
}

INT32 mqtt_client_msg_publish(UINT8 *buf)
{
    char pub_str[128];
    char pub_type = 3;
    UINT32 pub_len = 0;    

    ICT_SPRINTF(pub_str, "%d %s", pub_type, buf);
    pub_len = ICT_STRLEN(pub_str);

    return ict_api_mqtt_pub_handler(pub_str, pub_len);
}

INT32 mqtt_client_msg_subscribe(UINT8 *buf, UINT32 len, ICT_ST_MQTT_MSG_T *sub_msg)
{
    UINT8 str[2][128];
    UINT32  i = 0, j= 0, cnt = 0;
    INT32 rtn_val = ICT_TRUE;

    if(len == 0)
    {
        return ICT_FALSE;
    }

    for(cnt = 0; cnt < len; cnt++)
    {
        if((buf[cnt] == ' ') && (i == 0))
        {
            str[i][j] = 0;
            i = 1;
            j = 0;
        }
        else if((buf[cnt] == 0x0D) || (buf[cnt] == 0x0A))
        {
            str[i][j] = 0;
        }
        else
        {
            str[i][j++] = buf[cnt];
        }
    }
    
    sub_msg->len = ICT_ATOI(str[0]);
    if(sub_msg->len > 0)
    {
        ICT_STRCPY(sub_msg->buf, str[1]);
        sub_msg->buf[sub_msg->len] = 0;
    }
    else
    {
        return ICT_FALSE;
    }

    return rtn_val;
}

void user_event_handler(T_MAC_EVENT *p_mac_event)
{
    ICT_ST_MQTT_CNTX_T   *p_cntx;
    INT32 result;

    p_cntx = &mqtt_cntx;
    
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_JOIN_IND:
            printf("T: %s : %d : ICT_HIF_CMD_ST_JOIN_IND\n");
            result = ict_api_join_state(p_mac_event->buf);
            if(result == ICT_TRUE)
            {
                printf("T: [ASSOCIATED]\n");
                p_cntx->ap_asso = ICT_TRUE;
            }
            else
            {
                p_cntx->ap_asso = ICT_ERR;
                printf("E: Association failed\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("T: %s : %d : ICT_HIF_CMD_ST_DISCONNECTED_IND\n");
            printf("T: [DISASSOCIATED]\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;
                printf("T: %s : %d : ICT_HIF_CMD_ST_NETWORK_INFO_IND\n");                
                ICT_MEMCPY(&p_cntx->network_info, network_ind, sizeof(ICT_ST_NETWORK_INFO_IND_T));
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));

                p_cntx->ap_conn = ICT_TRUE;
                printf("T: %s : %d : [CONNECTED]\n");  
            }
            break;

        case ICT_HIF_CMD_ST_MQTT_PUB_IND:
            {
                printf("T: [MQTT_EXAM] MQTT_PUB_IND : len = %d\n", p_mac_event->len);
                
                mqtt_client_event_ind(p_mac_event->buf, p_mac_event->len, &p_cntx->pub_ind);

                if (p_cntx->pub_ind.result == ICT_TRUE)
                {
                    if (p_cntx->pub_ind.rst_code == MQTT_CONNECTED_SERVER)
                    {
                        p_cntx->pub_conn = ICT_TRUE;
                    }
                    else if (p_cntx->pub_ind.rst_code == MQTT_DISCONNECTED_SERVER)
                    {
                        p_cntx->pub_conn = ICT_FALSE;
                    }

                    printf("T: [MQTT_EXAM] MQTT_PUB_IND rst = %d : code = %d\n", p_cntx->pub_ind.result, p_cntx->pub_ind.rst_code);
                }
                else if (p_cntx->pub_ind.result == ICT_ERR)
                {
                    printf("T: [MQTT_EXAM] MQTT_PUB_IND Error : code = %d\n", p_cntx->sub_ind.err_code);
                }
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_SUB_IND:
            {
                printf("T: [MQTT_EXAM] MQTT_SUB_IND : len = %d\n", p_mac_event->len);
                
                mqtt_client_event_ind(p_mac_event->buf, p_mac_event->len, &p_cntx->sub_ind);

                if (p_cntx->sub_ind.result == ICT_TRUE)
                {
                    if (p_cntx->sub_ind.rst_code == MQTT_CONNECTED_SERVER)
                    {
                        p_cntx->sub_conn = ICT_TRUE;
                    }
                    else if (p_cntx->sub_ind.rst_code == MQTT_DISCONNECTED_SERVER)
                    {
                        p_cntx->sub_conn = ICT_FALSE;
                    }

                    printf("T: [MQTT_EXAM] MQTT_SUB_IND rst = %d : code = %d\n", p_cntx->sub_ind.result, p_cntx->sub_ind.rst_code);
                }
                else if (p_cntx->sub_ind.result == ICT_ERR)
                {
                    printf("T: [MQTT_EXAM] MQTT_SUB_IND Error : code = %d\n", p_cntx->sub_ind.err_code);
                }
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_PUB_RECV_IND:
            {
                printf("T: [MQTT_EXAM] MQTT_PUB_RECV_IND : len = %d\n", p_mac_event->len);
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_SUB_RECV_IND:
            {
                printf("T: [MQTT_EXAM] MQTT_SUB_RECV_IND : len = %d\n", p_mac_event->len);
                mqtt_client_msg_subscribe(p_mac_event->buf, p_mac_event->len, &p_cntx->sub_msg);
                printf("T: [MQTT_EXAM] sub_msg len = %d \n%s\n", p_cntx->sub_msg.len, p_cntx->sub_msg.buf);
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_IND:
            printf("D: [MQTT_EXAM] MQTT_IND : len = %d\n", p_mac_event->len);
            break;
            
        case ICT_HIF_CMD_ST_MQTT_RECV_IND:
            printf("D: [MQTT_EXAM] MQTT_RECV_IND : len = %d\n", p_mac_event->len);
            break;
            
        default:
            break;
    }
}

static void display_file_list(char *path)
{    
    UINT32 max_count = 10;
    UINT8 *p_out_list = ICT_NULL;
    UINT32 out_count = 0;
    UINT32 out_len = 0;
    int i;
    FILINFO *tmp;

    p_out_list = ICT_MALLOC(max_count * sizeof(FILINFO));
    if (p_out_list == ICT_NULL)
    {
        printf("E: malloc failed.\n");
        console_printf("\r\n File Display Error! \r\n");
        return;
    }
    
    printf("\n");
    out_len = ict_api_fs_scan_files(path, max_count, p_out_list, &out_count);
    if (out_len && out_count)
    {
        for (i = 0; i < out_count; i++)
        {
            tmp = (FILINFO *)(p_out_list + (i * sizeof(FILINFO)));
            printf("N: <%-4s> %-13s\t\t\t%4d bytes\n", (tmp->fattrib & AM_DIR)?"DIR":"FILE", tmp->fname, tmp->fsize);
            console_printf("\r\n <%-4s> %-13s\t\t\t%4d bytes", (tmp->fattrib & AM_DIR)?"DIR":"FILE", tmp->fname, tmp->fsize);
        }           
        console_printf("\r\n");
    }
}

INT32 mqtt_client_set_param(ICT_ST_MQTT_CNTX_T *p_cntx)
{
    ICT_ST_CONS_DATA_T  *p_cons_line;
    T_NMS_MQTT_MIB      *p_mib;
    char cmd_str[16];
    char *p_cons_str;
    INT32 result = ICT_FALSE;

    p_mib = ict_api_sta_mqtt_get();
    p_cntx->p_mqtt_mib = p_mib;
    
    p_cons_line = &cons_line_data;

    if(console_get_line(p_cons_line) == ICT_TRUE)
    {
        if(p_cons_line->len > 0)
        {
            p_cons_str = p_cons_line->buf;
            p_cons_str = ict_api_dm_shell_get_token(p_cons_str, cmd_str);

            if (ICT_STRCASECMP ("cert", cmd_str) == 0)
            {
                char file_str[32];

                p_cons_str = ict_api_dm_shell_get_token(p_cons_str, file_str);
                
                if (ICT_STRCASECMP ("pem", file_str) == 0)
                {
                    p_cons_str = ict_api_dm_shell_get_token(p_cons_str, file_str);
                    ICT_STRCPY(p_cntx->root_ca_file, file_str);
                    
                }
                else if (ICT_STRCASECMP ("crt", file_str) == 0)
                {
                    p_cons_str = ict_api_dm_shell_get_token(p_cons_str, file_str);
                    ICT_STRCPY(p_cntx->cert_file, file_str);
                }
                else if (ICT_STRCASECMP ("key", file_str) == 0)
                {
                    p_cons_str = ict_api_dm_shell_get_token(p_cons_str, file_str);
                    ICT_STRCPY(p_cntx->priv_key_file, file_str);
                }
                else
                {
                    console_printf(" @ UNKNOWN : %s \r\n", file_str);                    
                    console_printf(" @ ex) \r\n  # MQTT > cert pem ROOTCA.PEM\r\n");
                    console_printf("  # MQTT > cert crt CERT.CRT\r\n");
                    console_printf("  # MQTT > cert key PRIVATE.KEY\r\n");
                }

                p_cons_line->len = 0;
            }
            else if (ICT_STRCASECMP ("show", cmd_str) == 0)
            {
                char item_str[32];
                
                p_cons_str = ict_api_dm_shell_get_token(p_cons_str, item_str);
                
                if (ICT_STRCASECMP ("mib", item_str) == 0)
                {
                    mqtt_client_show_mib(p_mib);
                }
                else if (ICT_STRCASECMP ("fs", item_str) == 0)
                {
                    display_file_list("/");
                }
                else
                {
                    console_printf(" @ UNKNOWN : %s \r\n", item_str);
                }

                p_cons_line->len = 0;
            }
            else if (ICT_STRCASECMP ("mib", cmd_str) == 0)
            {
                UINT32 type = 0;
                char param_str[64];

                p_cons_str = ict_api_dm_shell_get_token(p_cons_str, param_str);
                type = ICT_ATOI(param_str);

                if(type < MQTT_MIB_MAX_PARAM)
                {
                    p_cons_str = ict_api_dm_shell_get_token(p_cons_str, param_str);
                    ict_api_sta_mqtt_set(type, param_str, ICT_STRLEN(param_str));
                    console_printf("\r\n => MQTT SET : [%d] %s \r\n", type, param_str);
                }
                else
                {
                    console_printf(" @ UNKNOWN : %d \r\n", type);
                }
                
                p_cons_line->len = 0;
            }
            else if(ICT_STRCASECMP ("quit", cmd_str) == 0)
            {
                if(ICT_STRLEN(p_cntx->root_ca_file) == 0)
                {
                    console_printf(" @ The pem is not set.\r\n");
                    console_printf(" @ ex) \r\n # MQTT > cert pem ROOTCA.PEM\r\n");
                }
                else if(ICT_STRLEN(p_cntx->cert_file) == 0) 
                {
                    console_printf(" @ The crt is not set.\r\n");
                    console_printf(" @ ex) \r\n # MQTT > cert crt CERT.CRT\r\n");
                }
                else if(ICT_STRLEN(p_cntx->priv_key_file) == 0)
                {
                    console_printf(" @ The key is not set.\r\n");
                    console_printf(" @ ex) \r\n # MQTT > cert key PRIVATE.KEY\r\n");
                }
                else
                {
                    ict_api_sta_mqtt_cert_set(p_cntx->root_ca_file, p_cntx->cert_file, p_cntx->priv_key_file);
                    
                    return ICT_TRUE;
                }

                p_cons_line->len = 0;
            }
            
            console_printf("\r\n # MQTT > ");
        }
        
        return result;
    }
}

void mqtt_client_proc(ICT_ST_MQTT_CNTX_T *p_cntx)
{
    ICT_ST_JOIN_REQ_T   *p_join_req;
    ICT_ST_CONS_DATA_T  *p_cons_line;
    INT32 result;

    p_join_req = &p_cntx->join_req;
    p_cons_line = &cons_line_data;

    switch(p_cntx->sm_state)
    {
    case MQTT_SM_CLI_INIT:
        p_cntx->ap_asso = ICT_FALSE;
        p_cntx->ap_conn = ICT_FALSE;
        
        ICT_MEMSET(p_join_req, 0, sizeof(ICT_ST_JOIN_REQ_T));
        p_cons_line->len = 0;

        console_printf("\r\n");
        console_printf("================================\r\n");
        console_printf("=          MQTT CLIENT         =\r\n");
        console_printf("================================\r\n");

        p_cntx->waiting_cnt = 0;
        p_cons_line->len = 0;        

        console_printf("\r\n # MQTT > ");
        p_cntx->sm_state = MQTT_SM_CLI_SET_PARAM;
            
        break;

    case MQTT_SM_CLI_SET_PARAM:
        if(mqtt_client_set_param(p_cntx) == ICT_TRUE)
        {
            console_printf("\r\n$ AP SSID : ");
            p_cons_line->len = 0;
            p_cntx->sm_state = MQTT_SM_CLI_INPUT_AP_SSID;
        }
        break;

    case MQTT_SM_CLI_INPUT_AP_SSID:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                console_printf("\r\n$ AP SSID : ");
                break;
            }
            
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->ssid, p_cons_line->buf);
            p_join_req->ssid_len = ICT_STRLEN(p_join_req->ssid);

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            console_printf("\r\n$ AP PASSWORD : ");
            p_cntx->sm_state = MQTT_SM_CLI_INPUT_AP_PASSWD;
        }
        break;
        
    case MQTT_SM_CLI_INPUT_AP_PASSWD:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            console_printf("\r\n  => %s\r\n", p_cons_line->buf);
            
            ICT_STRCPY(p_join_req->key, p_cons_line->buf);
            p_join_req->key_len = ICT_STRLEN(p_join_req->key);    

            p_cntx->waiting_cnt = 0;
            p_cons_line->len = 0;
            
            console_printf("\r\n Join Start...\r\n");
            p_cntx->sm_state = MQTT_SM_CLI_JOIN_AP;
        }
        else
        {
            p_cntx->waiting_cnt++;
            if(p_cntx->waiting_cnt > 3000) /* timeout 30sec */
            {
                console_printf("\r\n@ Input time exceeded. Restart!\r\n");
                p_cntx->sm_state = MQTT_SM_CLI_INIT;
            }
        }
        break;

    case MQTT_SM_CLI_JOIN_AP:
        ict_api_join_handler(p_join_req);
        p_cntx->sm_state = MQTT_SM_CLI_ASSOCIATION;
        break;
        
    case MQTT_SM_CLI_ASSOCIATION:
        if(p_cntx->ap_asso == ICT_TRUE)
        {
            p_cntx->sm_state = MQTT_SM_CLI_CONN_AP;
        }
        else if(p_cntx->ap_asso == ICT_ERR)
        {
            console_printf("\r\n Association Error!\r\n");
            console_printf("\r\n$ AP SSID : ");
            p_cntx->sm_state = MQTT_SM_CLI_INPUT_AP_SSID;
            p_cntx->ap_asso = ICT_FALSE;
            p_cons_line->len = 0;
        }
        break;
        
    case MQTT_SM_CLI_CONN_AP:
        if(p_cntx->ap_conn == ICT_TRUE)
        {
            console_printf("\r\n");
            console_printf(" IP       "IPSTR"\r\n", IP2STR(p_cntx->network_info.ipaddr));
            console_printf(" SUBNET   "IPSTR"\r\n", IP2STR(p_cntx->network_info.subnet));
            console_printf(" GATEWAY  "IPSTR"\r\n", IP2STR(p_cntx->network_info.gateway));
            console_printf(" DNS      "IPSTR"\r\n", IP2STR(p_cntx->network_info.dns));
                
            console_printf("\r\n Association Success!\r\n");
            console_printf("\r\n Client Start...\r\n");

            mqtt_client_connect_with_server();
            
            p_cntx->sm_state = MQTT_SM_CLI_CONN_SERVER;
        }
        break;

    case MQTT_SM_CLI_CONN_SERVER:
        if(p_cntx->sub_conn == ICT_TRUE)
        {
            console_printf("\r\n MQTT Broker Connection! \r\n");
            p_cons_line->len = 0;
            console_printf("\r\n PUB > ");
            p_cntx->sm_state = MQTT_SM_CLI_MSG_PUB;
        }
        break;

    case MQTT_SM_CLI_MSG_PUB:
        if(console_get_line(p_cons_line) == ICT_TRUE)
        {
            if(p_cons_line->len == 0)
            {
                console_printf("\r\n PUB > ");
                break;
            }

            mqtt_client_msg_publish(p_cons_line->buf);
            p_cons_line->len = 0;
            
            console_printf("\r\n PUB > ");
        }
        else if(p_cntx->sub_msg.len)
        {
            console_printf("\r\n SUB > %s \r\n", p_cntx->sub_msg.buf);
            p_cntx->sub_msg.len = 0;
            console_printf("\r\n PUB > ");
        }
        break;
        
    default:
        break;
    }
}

static void mqtt_client_task(void *arg)
{
    arg = arg;
    static UINT32 cnt = 1, pub_num = 0;
    ICT_ST_MQTT_CNTX_T  *p_cntx;

    p_cntx = &mqtt_cntx;
    ICT_MEMSET(p_cntx, 0, sizeof(ICT_ST_MQTT_CNTX_T));
#if USE_CONSOLE_PORT    
    p_cntx->sm_state = MQTT_SM_CLI_INIT;
#endif
    printf("\n");
    printf("==============================================\n");
    printf("=          MQTT Client Task Started.         =\n");
    printf("==============================================\n");    
    
    while(1)
    {
#if USE_CONSOLE_PORT
        mqtt_client_proc(p_cntx);
#else  
        if(p_cntx->ap_conn == ICT_TRUE)
        {
            if(cnt == 200)
            {
                mqtt_client_connect_with_server();
                printf("# Request Connection MQTT Server #\n");
            }

            if(((cnt % 1000) == 0) && (pub_num < 3))
            {
                mqtt_client_msg_publish("Test Message");
                pub_num++;
            }
            cnt++;
        }
#endif /* USE_CONSOLE_PORT */
        ict_api_tn_task_sleep(1);
    }        
}

void user_start(void)
{
    UINT8 aucon_mode;
    
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
    printf("=== Start baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));
    //ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- mqtt_client\n\n");

#if USE_CONSOLE_PORT
    ict_api_nv_get_auconmode(&aucon_mode);
    if(aucon_mode)
    {
        aucon_mode = 0;
        ict_api_nv_set_auconmode(&aucon_mode);
    }

    console_port_config();
#else
    mqtt_client_set();
    wlan_config();
#endif
    ict_cm_wlan_event_callback_register((void *)user_event_handler);

    ict_api_tn_task_sleep(10);     // 100msec sleep

    /* create task */
    if (p_mqtt_task == ICT_NULL)
    {
        INT32 result;

        ict_api_tn_task_event_create(&uart_event_group, 0x00);
        
        p_mqtt_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_mqtt_task == ICT_NULL)
        {
            printf("p_mqtt_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_mqtt_task, 0x00, sizeof(*p_mqtt_task));
        ICT_MEMSET(mqtt_task_stack, 0x00, sizeof(mqtt_task_stack));

        result = ict_api_tn_task_create(p_mqtt_task, 
                                        "mqtt",
                                        mqtt_client_task, 
                                        NULL, 
                                        &mqtt_task_stack[MQTT_TASK_STACK_SIZE-1], 
                                        MQTT_TASK_STACK_SIZE, 
                                        MQTT_TASK_PRI);

        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    return;
}


