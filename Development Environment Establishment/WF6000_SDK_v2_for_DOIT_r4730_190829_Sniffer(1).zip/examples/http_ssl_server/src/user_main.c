/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define HTTP_SSL_TASK_STACK_SIZE    1024
#define HTTP_SSL_TASK_PRI           1

#define LOCAL_DNS_QUERY_HOST_NAME   "server.test"
    
/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    TCP_SSL_TYPE_CONNECT,
    TCP_SSL_TYPE_SEND
} tcp_ssl_ind_t;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_http_ssl_task = ICT_NULL;
DWALIGN OS_STK http_ssl_task_stack[HTTP_SSL_TASK_STACK_SIZE] XDWALIGN;

static UINT8 b_associated = ICT_FALSE;
static UINT8 b_connected = ICT_FALSE;
static UINT8 b_started = ICT_FALSE;
static UINT32 server_sock_fd = -1;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void wlan_config(void)
{
    INT32 result;
    
    /*                 [ssid] [ch/freq] {wep/wpa/wpa2} {tkip/ccmp} {tkip/ccmp} {passphrase} */
    /* ap_connect[] = "anytest   149        wpa2           ccmp       ccmp       12345678" */
    uint8_t ap_connect[128];

    printf("[%s] called.", __func__);
    
    /* if needed, set IP config */
    if (1)
    {
        uint8_t ip[4], subnet[4], gateway[4], lease_ip_min, lease_ip_max;

        IP4_ADDR_(ip, 192, 168, 43, 1);
        IP4_ADDR_(subnet, 255, 255, 255, 0);
        IP4_ADDR_(gateway, 192, 168, 43, 1);
        lease_ip_min = 20;
        lease_ip_max = 200;

        ict_api_nv_set_apnet(ip, subnet, gateway, &lease_ip_min, &lease_ip_max);
    }

    ICT_MEMSET(ap_connect, 0x00, 128);
    ICT_SPRINTF(ap_connect, "HTTPS_TEST 9");
    
    result = ict_api_apconn_handler(ICT_FALSE, ap_connect, (UINT32)ICT_STRLEN((char*)ap_connect));
    
    printf("[%s] result(%d)\n", __func__, result);
}

void https_server_start()
{
    UINT16 port;
    INT32 result;

    port = 443;   

    result = ict_api_set_dns_query_host_name(LOCAL_DNS_QUERY_HOST_NAME);
    if(result != ICT_OK)
    {
        printf("E: host_name setting error!\n");
    }
    
    result = ict_api_tcp_ssl_svr_start_handler(port);
    printf("[%s] result: %d\n", __func__, result);        
}

void https_server_close(int sock_fd)
{
    INT32 result;
    
    result = ict_api_tcp_ssl_svr_close_handler(sock_fd);
    printf("[%s] result: %d\n", __func__, result);      
}

void https_server_response(int sock_fd)
{
    UINT8 rsp_http_buf[256], rsp_http_body[128];
    UINT32 len = 0, body_len = 0;
    INT32 result;

    ICT_MEMSET(rsp_http_buf, 0x00, sizeof(rsp_http_buf));
    ICT_MEMSET(rsp_http_body, 0x00, sizeof(rsp_http_body));
                
    body_len =  ICT_SPRINTF((char *)&rsp_http_body[0], "<h2>HTTPS Test Server by I&C Technology.</h2>\r\n");
    body_len += ICT_SPRINTF((char *)&rsp_http_body[body_len], "<p>Successful connection</p>\r\n");

    len  = ICT_SPRINTF((char *)&rsp_http_buf[0], "HTTP/1.0 200 OK\r\n");
    len += ICT_SPRINTF((char *)&rsp_http_buf[len], "Content-Type: text/html\r\n");
    len += ICT_SPRINTF((char *)&rsp_http_buf[len], "Pragma: no-cache\r\n");
    len += ICT_SPRINTF((char *)&rsp_http_buf[len], "Content-length: %d\r\n", body_len);
    len += ICT_SPRINTF((char *)&rsp_http_buf[len], "\r\n");
    len += ICT_SPRINTF((char *)&rsp_http_buf[len], "%s", rsp_http_body);

    ict_api_tcp_ssl_svr_info_handler((UINT32)sock_fd);
    result = ict_api_tcp_ssl_svr_send_handler(rsp_http_buf, len);
    printf("[%s] sock_fd(%d) rsp_len(%d) result:%d \n", __func__, sock_fd, len, result);
    //MSG_PRINTF(rsp_http_buf);
}

void user_event_handler(T_MAC_EVENT *p_mac_event)
{
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_JOIN_IND:
            if(ict_api_join_state(p_mac_event->buf) == ICT_TRUE)
            {
                printf("N: [ASSOCIATED]\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("N: [DISASSOCIATED]\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));
                
                b_associated = ICT_TRUE;
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_CLOSE_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("N: [DISCONNECT] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);

                if (ssl_ind->result == 0) 
                    b_connected = ICT_FALSE;
            }
            break;  

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                if (ssl_ind->type == TCP_SSL_TYPE_CONNECT)
                {
                    printf("N: [SVR_START] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));

                    if (ssl_ind->result == 0)
                    {
                        b_started = ICT_TRUE;
                        server_sock_fd = ssl_ind->socket_desc;
                    }
                }
                else if (ssl_ind->type == TCP_SSL_TYPE_SEND)
                {
                    printf("N: [SEND] sock(%d) result(%s)\n", ssl_ind->socket_desc, (ssl_ind->result == 0 ? "OK" : "ERROR"));
                }
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_RECV_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("N: [RECV] sock(%d) len(%d)\n", ssl_ind->socket_desc, ssl_ind->data_len);                
                MSG_PRINTF(ssl_ind->data);
                
                https_server_response(ssl_ind->socket_desc);
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_CLOSE_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("N: [SVR STOP] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);

                if (ssl_ind->result == 0) 
                    b_started = ICT_FALSE;
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_ACCEPTED_IND:
            {
                ICT_ST_TCP_SSL_IND_T *ssl_ind;
                ssl_ind = (ICT_ST_TCP_SSL_IND_T *)p_mac_event->buf;

                printf("N: [ACCEPT] sock(%d) result(%d)\n", ssl_ind->socket_desc, ssl_ind->result);
            }
            break;
                      
        default:
            break;
    }
}

static void http_ssl_server_task(void *arg)
{
    arg = arg;
    static int num;
    INT32 result;

    printf("\n");
    printf("==============================================\n");
    printf("=          HTTPS Server task started.        =\n");
    printf("==============================================\n");

    while(1)
    {
        if(b_associated == ICT_TRUE)
        {
            if(num == 100)
            {
                https_server_start();
            }
            num++;        
        }
        
        ict_api_tn_task_sleep(1);     // 1000 msec sleep        
    }    
    
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- https server\n\n");

    wlan_config();
    ict_cm_wlan_event_callback_register((void *)user_event_handler);

    /* create task */
    if (p_http_ssl_task == ICT_NULL)
    {
        INT32 result;
        
        p_http_ssl_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_http_ssl_task == ICT_NULL)
        {
            printf("p_http_ssl_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_http_ssl_task, 0x00, sizeof(*p_http_ssl_task));
        ICT_MEMSET(http_ssl_task_stack, 0x00, sizeof(http_ssl_task_stack));

        result = ict_api_tn_task_create(p_http_ssl_task, 
                                        "https_server", 
                                        http_ssl_server_task, 
                                        NULL, 
                                        &http_ssl_task_stack[HTTP_SSL_TASK_STACK_SIZE-1], 
                                        HTTP_SSL_TASK_STACK_SIZE, 
                                        HTTP_SSL_TASK_PRI);
        
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    return;
}


