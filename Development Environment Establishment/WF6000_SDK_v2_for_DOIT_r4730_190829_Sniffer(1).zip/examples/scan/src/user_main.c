/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"
#include "user_config.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
static wlan_scan_ap_list_t *p_scan_head = ICT_NULL;


/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/
void wlan_init_scan_ap_list()
{
    wlan_scan_ap_list_t *now_node = p_scan_head;
    wlan_scan_ap_list_t *tmp_node;

    while (now_node != ICT_NULL)
    {
        tmp_node = now_node;
        now_node = now_node->next;

        ict_api_mfree(tmp_node);
    }

    p_scan_head = ICT_NULL;
}

void wlan_insert_scan_ap_list(ICT_ST_SCAN_IND_T *p_scan_ind)
{
    wlan_scan_ap_list_t *now_node = p_scan_head;
    wlan_scan_ap_list_t *tmp_node = ICT_NULL;

    /* 1. If exist a same BSSID, update that */
    while (now_node != ICT_NULL)
    {
        if (ict_api_memcmp(now_node->ap_info.bssid, p_scan_ind->bssid, MAC_ADDR_LEN) == 0)
        {
            ict_api_memcpy(&now_node->ap_info, p_scan_ind, sizeof(ICT_ST_SCAN_IND_T));
            return;
        }
        now_node = now_node->next;
    }

    tmp_node = (wlan_scan_ap_list_t *)ict_api_malloc(sizeof(wlan_scan_ap_list_t));
    ict_api_memset(tmp_node, 0x00, sizeof(wlan_scan_ap_list_t));
    ict_api_memcpy(&tmp_node->ap_info, p_scan_ind, sizeof(ICT_ST_SCAN_IND_T));

    /* 2. Check Head list */
    if (p_scan_head == ICT_NULL ||                                                      /* head is NULL */
        (p_scan_head != ICT_NULL && p_scan_head->ap_info.rssi <= tmp_node->ap_info.rssi))     /* head is weaker than new */
    {
        tmp_node->next = p_scan_head;
        p_scan_head = tmp_node;
        return;
    }

    /* 3. Check other list (If empty or weaker RSSI, add a list before that) */
    now_node = p_scan_head;
    while (now_node != ICT_NULL)
    {
        if (now_node->next == ICT_NULL)
        {
            now_node->next = tmp_node;
            return;
        }
        else
        {
            if (now_node->next->ap_info.rssi <= tmp_node->ap_info.rssi)
            {
                tmp_node->next = now_node->next;
                now_node->next = tmp_node;
                return;
            }            
        }
        
        now_node = now_node->next;
    }

    printf("E: [%s] ERROR!\n", __func__);
    
    return;    
}

void wlan_print_scan_ap_list()
{
    wlan_scan_ap_list_t *now_node = p_scan_head;
    ICT_ST_SCAN_IND_T *ptr;

    printf("************************* AP List *****************************\n");
    printf(" CH  SSID                                BSSID            RSSI\n");
    while ( now_node != ICT_NULL )
    {
        ptr = &now_node->ap_info;
        printf(" %3d %-32s "ICT_MACSTR"    %d\n", ptr->ch, ptr->ssid, ICT_MAC2STR(ptr->bssid), ptr->rssi);
        now_node = now_node->next;
    }
    printf("***************************************************************\n");
    
    return;
}

void wlan_start_scan(ICT_ST_SCAN_REQ_T *scan_params)
{
    ict_api_scan_handler(scan_params);
}

void wlan_scan_event_handler(T_MAC_EVENT *p_mac_event)
{
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_SCAN_IND:
            printf("---- ICT_HIF_CMD_ST_SCAN_IND.\n");
            if (p_mac_event->buf)
            {
                ICT_ST_SCAN_IND_T *p_scan_ind = (ICT_ST_SCAN_IND_T *)p_mac_event->buf;

                wlan_insert_scan_ap_list(p_scan_ind);
            }
            break;

        case ICT_HIF_CMD_ST_SCAN_RST_IND:
            printf("---- ICT_HIF_CMD_ST_SCAN_RST_IND\n");
            wlan_print_scan_ap_list();
            break;

        default:
            printf("E:[%s] unknown event. (%X)\n", __func__, p_mac_event->code);
            break;
    }    
}


void user_start(void)
{
    ICT_ST_SCAN_REQ_T params;
	UINT16 channel_list[] = {
    	1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
    	36, 40, 44, 48, 
    	52, 56, 60, 64, 
    	100, 104, 108, 112, 116, 
    	120, 124, 128, 
    	149, 153, 157, 161, 165,
        0
	};

    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- scan\n\n");

    printf("--- init scan list.\n");
    wlan_init_scan_ap_list();
    
    printf("--- register scan callback function.\n");
    ict_cm_wlan_scan_event_callback_register(wlan_scan_event_handler);
           
    ict_api_memset(&params, 0x00, sizeof(ICT_ST_SCAN_REQ_T));
    params.channel = channel_list;

    /* all scan */
    if (1)
    {        
        printf("--- start to scan\n");
        wlan_start_scan(&params);
    }

    /* specific scan */
    if (1)
    {
        ict_api_memset(params.ssid, 0x00, 32);
        ict_api_strcpy(params.ssid, "KNOWN_SSID");
        params.ssid_len = ict_api_strlen((char*)params.ssid);
        
        printf("--- start to scan the specific SSID (%s)\n", params.ssid);
        wlan_start_scan(&params);
    }

    return;
}


