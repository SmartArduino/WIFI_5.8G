/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define PWM_TASK_STACK_SIZE         (1024)
#define PWM_TASK_PRI                (1)

#define PWM1_INTERRUPT_MODE         (1)
#define PWM2_INTERRUPT_MODE         (1)

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

enum
{
    PWM_CHANNEL_1 = 0,
    PWM_CHANNEL_2
};

enum
{
	PWM_INVAL_ms = 0,
	PWM_INVAL_us,
	PWM_INVAL_100ns
};

enum
{
	GENERAL_MODE = 0,
	PWM_MODE 
};

enum
{
    PWM_DISABLE = 0,
    PWM_ENABLE
};

typedef enum
{
    INTR_FSM_IDLE,
    INTR_FSM_DEBOUNCE,
    INTR_FSM_LED_CTRL,
    INTR_FSM_END
}
INTR_BTN_FSM;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_pwm_task = ICT_NULL;
DWALIGN OS_STK pwm_task_stack[PWM_TASK_STACK_SIZE] XDWALIGN;

static UINT32 pwm1_low_duration = 0, pwm1_high_duration = 0;
static UINT32 pwm2_low_duration = 0, pwm2_high_duration = 0;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void pwm_ch1_intr_handler(void)
{
#if PWM1_INTERRUPT_MODE
    if(pwm1_low_duration == 0x00000000)
    {
        pwm1_low_duration = 0x000000FE;
    }    
    pwm1_high_duration = ((~pwm1_low_duration) & 0x000000FF);
    ict_api_pwm_set_timer_count(PWM_CHANNEL_1, PWM_INVAL_ms, (pwm1_low_duration*1), (pwm1_high_duration*1));

    pwm1_low_duration--;
#endif    
}

void pwm_ch2_intr_handler(void)
{
#if PWM2_INTERRUPT_MODE
    if(pwm2_low_duration == 0x00000000)
    {
        pwm2_low_duration = 0x000000FE;
    }    
    pwm2_high_duration = ((~pwm2_low_duration) & 0x000000FF);
    ict_api_pwm_set_timer_count(PWM_CHANNEL_2, PWM_INVAL_ms, (pwm2_low_duration*1), (pwm2_high_duration*1));

    pwm2_low_duration--;
#endif    
}

void pwm_init(void)
{   
    ict_api_pwm_init();


    pwm1_low_duration = 0x000000FE;
    pwm1_high_duration = ((~pwm1_low_duration) & 0x000000FF);    
        
    ict_api_pwm_set_pad(PWM_CHANNEL_1, PWM_ENABLE);    
    ict_api_pwm_set_timer_count(PWM_CHANNEL_1, PWM_INVAL_ms, pwm1_low_duration, pwm1_high_duration);     
    ict_api_pwm_set_mode(PWM_CHANNEL_1, PWM_MODE);    
    ict_api_pwm_set_repeat(PWM_CHANNEL_1, PWM_ENABLE); 
#if PWM1_INTERRUPT_MODE    
    ict_api_pwm_set_interrupt(PWM_CHANNEL_1, PWM_ENABLE, pwm_ch1_intr_handler);    
#else    
    ict_api_pwm_set_interrupt(PWM_CHANNEL_1, PWM_DISABLE, NULL);    
#endif
    ict_api_pwm_enable(PWM_CHANNEL_1);


    pwm2_low_duration = 0x000000FE;
    pwm2_high_duration = ((~pwm2_low_duration) & 0x000000FF);
    
    ict_api_pwm_set_pad(PWM_CHANNEL_2, PWM_ENABLE);    
    ict_api_pwm_set_timer_count(PWM_CHANNEL_2, PWM_INVAL_ms, pwm2_low_duration, pwm2_high_duration);     
    ict_api_pwm_set_mode(PWM_CHANNEL_2, PWM_MODE);    
    ict_api_pwm_set_repeat(PWM_CHANNEL_2, PWM_ENABLE); 
#if PWM2_INTERRUPT_MODE
    ict_api_pwm_set_interrupt(PWM_CHANNEL_2, PWM_ENABLE, pwm_ch2_intr_handler);    
#else
    ict_api_pwm_set_interrupt(PWM_CHANNEL_2, PWM_DISABLE, NULL);    
#endif    
    ict_api_pwm_enable(PWM_CHANNEL_2);
}

static void pwm_task(void *arg)
{
    UINT16  out_val = 0;
    
    arg = arg;

    printf("\n");
    printf("==============================================\n");
    printf("=           pwm task started.                =\n");
    printf("==============================================\n");

    while(1)
    {
#if !PWM1_INTERRUPT_MODE
        if(pwm1_low_duration == 0x00000000)
        {
            pwm1_low_duration = 0x000000FE;
        }    
        pwm1_high_duration = ((~pwm1_low_duration) & 0x000000FF);
        ict_api_pwm_set_timer_count(PWM_CHANNEL_1, PWM_INVAL_ms, (pwm1_low_duration*1), (pwm1_high_duration*1));
        pwm1_low_duration--;
#endif

#if !PWM2_INTERRUPT_MODE
        if(pwm2_low_duration == 0x00000000)
        {
            pwm2_low_duration = 0x000000FE;
        }    
        pwm2_high_duration = ((~pwm2_low_duration) & 0x000000FF);
        ict_api_pwm_set_timer_count(PWM_CHANNEL_2, PWM_INVAL_ms, (pwm2_low_duration*1), (pwm2_high_duration*1));
        pwm2_low_duration--;
#endif

        ict_api_os_time_delay(10); // 10ms 
    }
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- pwm\n\n");
    
    pwm_init();

    /* create task */
    if (p_pwm_task == ICT_NULL)
    {
        INT32 result;

        p_pwm_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_pwm_task == ICT_NULL)
        {
            printf("p_pwm_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_pwm_task, 0x00, sizeof(*p_pwm_task));
        ICT_MEMSET(pwm_task_stack, 0x00, sizeof(pwm_task_stack));
        
        result = ict_api_tn_task_create(p_pwm_task, 
                                        "gpio",
                                        pwm_task, 
                                        NULL, 
                                        &pwm_task_stack[PWM_TASK_STACK_SIZE-1], 
                                        PWM_TASK_STACK_SIZE, 
                                        PWM_TASK_PRI);
    }
    
    return;
}

