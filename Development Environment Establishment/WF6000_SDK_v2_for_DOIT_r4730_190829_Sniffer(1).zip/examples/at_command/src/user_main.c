/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/
#define UART_TASK_STACK_SIZE    1024
#define UART_TASK_PRI           1

#define EVENT_MASK_USER_UART_RX 0x00000001

#define AT_CMD_MAX_CHAR         128

#define AT_CMD_START_CHAR       7
#define AT_CMD_START_CH_1       'A'
#define AT_CMD_START_CH_2       'T'
#define AT_CMD_START_CH_3       '*'
#define AT_CMD_START_CH_4       'I'
#define AT_CMD_START_CH_5       'C'
#define AT_CMD_START_CH_6       'T'
#define AT_CMD_START_CH_7       '*'

#define AT_CMD_END_CHAR         2
#define AT_CMD_END_CH_1         0x0D
#define AT_CMD_END_CH_2         0x0A

typedef enum
{
    AT_CMD_NONE,
    AT_CMD_START_1,     /* A */
    AT_CMD_START_2,     /* T */
    AT_CMD_START_3,     /* * */
    AT_CMD_START_4,     /* I */
    AT_CMD_START_5,     /* C */
    AT_CMD_START_6,     /* T */
    AT_CMD_START_7,     /* * */
    AT_CMD_COLLECTING,
    AT_CMD_END_1,       /* 0x0D */
    AT_CMD_END_2,       /* 0x0A */
} AT_STATE_E;

#define AT_CMD_DELIMITER        ':'
#define AT_CMD_RSP_STRING       "*ICT*"

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/
typedef struct 
{
    UINT8 *cmd;
    UINT8 cmd_len;
    INT32   (*cmd_proc_func_ptr)(UINT8 *cmd_buffer, UINT32 cmd_len, UINT8 *response_buffer, UINT32 *response_len);
} UART_CMD_TABLE_T;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
TN_TCB              *p_uart_task;
DWALIGN OS_STK      uart_task_stack[UART_TASK_STACK_SIZE] XDWALIGN;
DWALIGN TN_EVENT    uart_event_group XDWALIGN;

const UART_CMD_TABLE_T uart_cmd_tbl[] =
{
    {(UINT8 *)"SWVER",              5, ict_app_uart_cmd_swver},
    {(UINT8 *)"FWVER",              5, ict_app_uart_cmd_fwver},
    {(UINT8 *)"MAC",                3, ict_app_uart_cmd_mac},
    {(UINT8 *)"RESET",              5, ict_app_uart_cmd_reset},

    {NULL,                          0, NULL}                    /* Last of Table. Don't remove! */
};
/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/
void uart_write(UINT8 *buffer, UINT32 len)
{
    ict_api_uart_direct_send_w_size(UART2, buffer, len);
}

void uart_cmd_process(UINT8 *cmd, UINT32 cmd_len)
{
    UINT8 i = 0;
    UINT8 rsp_buf_1[256], rsp_buf_2[270];
    UINT32 rsp_len = 0;
    
    printf("[%s] len(%d) cmd(%s)\n", __func__, cmd_len, cmd);

    ict_api_memset(rsp_buf_1, 0x00, sizeof(rsp_buf_1));
    ict_api_memset(rsp_buf_2, 0x00, sizeof(rsp_buf_2));

    while (1)
    {
        if (uart_cmd_tbl[i].cmd_len == 0)
            break;

        if (ict_api_strncasecmp((char *)cmd, (char *)uart_cmd_tbl[i].cmd, uart_cmd_tbl[i].cmd_len) == 0)
        {
            cmd += uart_cmd_tbl[i].cmd_len;
            cmd_len -= uart_cmd_tbl[i].cmd_len;
            uart_cmd_tbl[i].cmd_proc_func_ptr(cmd, cmd_len, rsp_buf_1, &rsp_len);

            if (rsp_len)
            {
                rsp_len = ICT_SPRINTF(rsp_buf_2, "%s%s%c%s%c", AT_CMD_RSP_STRING, 
                                                            uart_cmd_tbl[i].cmd, 
                                                            AT_CMD_DELIMITER,
                                                            rsp_buf_1, 
                                                            AT_CMD_END_CH_1);
                uart_write(rsp_buf_2, rsp_len);
            }

            return;
        }

        i++;
    }

    printf("[%s] Unknown Command.\n", __func__);
    
}

void uart_rx_process(UINT8 *buffer, UINT32 len)
{
    static AT_STATE_E state = AT_CMD_NONE;
    static UINT8 cmd_buffer[AT_CMD_MAX_CHAR];
    static UINT32 cmd_len;
    UINT8  c;

    while (len--)
    {
        c = *buffer;
        //printf("ch(%X) len(%d)\n", c, len);

        switch (state)
        {
            case AT_CMD_NONE:
                if (c == AT_CMD_START_CH_1) 
                    state = AT_CMD_START_1;
                break;
                
            case AT_CMD_START_1:
                if (c == AT_CMD_START_CH_2) 
                    state = AT_CMD_START_2;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_START_2:
                if (c == AT_CMD_START_CH_3) 
                    state = AT_CMD_START_3;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_START_3:
                if (c == AT_CMD_START_CH_4) 
                    state = AT_CMD_START_4;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_START_4:
                if (c == AT_CMD_START_CH_5) 
                    state = AT_CMD_START_5;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_START_5:
                if (c == AT_CMD_START_CH_6) 
                    state = AT_CMD_START_6;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_START_6:
                if (c == AT_CMD_START_CH_7) 
                    state = AT_CMD_COLLECTING;
                else
                    state = AT_CMD_NONE;
                break;
                
            case AT_CMD_COLLECTING:
                cmd_buffer[cmd_len++] = c;
                if (c == AT_CMD_END_CH_1)
                    state = AT_CMD_END_1;
                break;
                
            case AT_CMD_END_1:
                if (c == AT_CMD_END_CH_2)
                {
                    cmd_buffer[--cmd_len] = 0;
                    uart_cmd_process(cmd_buffer, cmd_len);

                    ict_api_memset(cmd_buffer, 0x00, sizeof(cmd_buffer));
                    cmd_len = 0;
                    state = AT_CMD_NONE;
                }
                else
                {
                    cmd_buffer[cmd_len++] = c;
                    state = AT_CMD_COLLECTING;
                }
                break;
                
            default:
                break;
        }

        if (cmd_len >= sizeof(cmd_buffer))
        {
            printf("W: [%s] uart rx overflow. (%d)\n", __func__, cmd_len);

            ict_api_memset(cmd_buffer, 0x00, sizeof(cmd_buffer));
            cmd_len = 0;
            state = AT_CMD_NONE;
        }
        
        buffer++;
    }

    
}



/* called by ISR function */
static void uart_rx_int_cb(void)
{
    ict_api_tn_task_event_set(&uart_event_group, EVENT_MASK_USER_UART_RX);
}

static void uart_task(void *arg)
{
    arg = arg;
    OS_FLAGS masked_event;
    OS_FLAGS waiting_event = EVENT_MASK_USER_UART_RX;

    ict_api_uart_init(UART2);
    ict_api_uart_open(UART2);    
    ict_api_uart_reg_rx_callback (UART2, uart_rx_int_cb);
    ict_api_uart_change_baudrate (UART2, 115200, fMACWLEN(UART_WORD_LEN_8BITS));

    {
        char buffer[32];
        UINT8 len;

        len = ict_api_sprintf(buffer, "%sDEVICEREADY%c", AT_CMD_RSP_STRING, AT_CMD_END_1);
        uart_write(buffer, len);
    }

    while (1)
    {
        masked_event = ict_api_tn_task_event_wait(&uart_event_group, waiting_event, 0);
        if (masked_event & EVENT_MASK_USER_UART_RX)
        {
            char buff[64];
            int size = 0;

            do
            {
                size = ict_api_uart_gets(UART2, buff, sizeof(buff));
                if (size != ICT_ERR)
                {
                    uart_rx_process((UINT8 *)buff, size);
                }
            } while (size);
        }
    }    
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));    
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- at command\n\n");

    /* create task */
    if (p_uart_task == ICT_NULL)
    {
        INT32 result;

        ict_api_tn_task_event_create(&uart_event_group, 0x00);

        p_uart_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_uart_task == ICT_NULL)
        {
            printf("p_wlan_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_uart_task, 0x00, sizeof(*p_uart_task));
        ICT_MEMSET(uart_task_stack, 0x00, sizeof(uart_task_stack));

        result = ict_api_tn_task_create(p_uart_task, 
                                        "uart", 
                                        uart_task, 
                                        NULL, 
                                        &uart_task_stack[UART_TASK_STACK_SIZE-1], 
                                        UART_TASK_STACK_SIZE, 
                                        UART_TASK_PRI);
        
        printf("ict_api_tn_task_create result(%d)\n", result);
    }
    
    return;
}


