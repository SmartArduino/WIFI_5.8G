/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/
#define MODE_AP                 1

#define WLAN_TASK_STACK_SIZE    1024
#define WLAN_TASK_PRI           1

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    WLAN_AP_MODE = 0,
    WLAN_STATION_MODE
}
WLAN_MODE;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
TN_TCB *p_wlan_task = ICT_NULL;
DWALIGN OS_STK wlan_task_stack[WLAN_TASK_STACK_SIZE] XDWALIGN;

static WLAN_MODE opration_mode = WLAN_STATION_MODE; // WLAN_AP_MODE or WLAN_STATION_MODE
/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void wlan_get_mac_address(UINT8 *p_mac)
{
    BOOL result;
    UINT8 len;

    result = ict_api_mac_mib_get_wifi_cfg(WIFI_CFG_MAC_ADDR, p_mac, &len);
    printf("MAC: "ICT_MACSTR"\n", ICT_MAC2STR(p_mac));
}

void wlan_get_ip_address(UINT32 *p_ip)
{
    UINT32 len;
    UINT32 read_mib;

    ict_api_mac_mib_get_wifi_cfg_ext(MIB_DATA_TYPE, WIFI_CFG_IP_ADDR, &read_mib, &len);
    *p_ip = ( ((read_mib & 0xff000000) >> 24) |
            ((read_mib & 0x00ff0000) >>  8) |
            ((read_mib & 0x0000ff00) <<  8) |
            ((read_mib & 0x000000ff) << 24));

    printf("read_mib: %08X, *ip: %08X", read_mib, *p_ip);    
}

void wlan_get_gw_address(UINT32 *p_ip)
{
    UINT32 len;

    ict_api_mac_mib_get_wifi_cfg_ext(MIB_DATA_TYPE, WIFI_CFG_GATEWAY_ADDR, p_ip, &len);
    printf("gw_ip: %08X\n", *p_ip);
}

void wlan_get_rssi(INT16 *p_rssi)
{
    UINT32 len;
    
    ict_api_mac_mib_get_wifi_cfg_ext(MIB_DATA_TYPE, WIFI_CFG_RSSI, p_rssi, &len);

    printf("rssi: %d\n", *p_rssi);
}

void wlan_operation_mode_ap_start()
{
    INT32 result;
    uint8_t mac_addr[6];
    
    /*                 [ssid] [ch/freq] {wep/wpa/wpa2} {tkip/ccmp} {tkip/ccmp} {passphrase} */
    /* ap_connect[] = "anytest   149        wpa2           ccmp       ccmp       12345678" */
    uint8_t ap_connect[128];

    printf("[%s] called.", __func__);
    
    /* if needed, set IP config */
    if (1)
    {
        uint8_t ip[4], subnet[4], gateway[4], lease_ip_min, lease_ip_max;

        IP4_ADDR_(ip, 192, 168, 43, 1);
        IP4_ADDR_(subnet, 255, 255, 255, 0);
        IP4_ADDR_(gateway, 192, 168, 43, 1);
        lease_ip_min = 20;
        lease_ip_max = 200;

        ict_api_nv_set_apnet(ip, subnet, gateway, &lease_ip_min, &lease_ip_max);
    }

    wlan_get_mac_address(mac_addr);

    ICT_MEMSET(ap_connect, 0x00, 128);
    ICT_SPRINTF(ap_connect, "TEST_AP 149 wpa2 ccmp ccmp 12345678");
    
    result = ict_api_apconn_handler(ICT_FALSE, ap_connect, (UINT32)ICT_STRLEN((char*)ap_connect));
    
    printf("[%s] result(%d)\n", __func__, result);
}

void wlan_operation_mode_ap_stop()
{
    printf("[%s] called.\n", __func__);
    ict_api_apstop_handler();
}

void wlan_operation_mode_station_start()
{
    UINT8 ssid[32] = "tset_ap"; /* SSID */
    UINT8 password[32] = ""; /* or "12345678" */
    UINT16 dhcp_en = ICT_TRUE; /* DHCP */  
    ICT_ST_IP_CONFIG_T params;
    ICT_ST_JOIN_REQ_T join_req;
    INT32 result;
    UINT32 cnt;

    ICT_MEMSET(&params, 0x00, sizeof(ICT_ST_IP_CONFIG_T));

    params.dhcp_mode = dhcp_en;    
    if(dhcp_en == ICT_FALSE)
    {   
        /* Example Static IP */        
        IP4_ADDR_(params.ipaddr, 10, 0, 0, 10);
        IP4_ADDR_(params.subnet, 255, 255, 255, 0);
        IP4_ADDR_(params.gateway, 10, 0, 0, 1);
        IP4_ADDR_(params.dns, 164, 124, 101, 2);            
    }

    ICT_MEMSET(&join_req, 0x00, sizeof(ICT_ST_JOIN_REQ_T));
    join_req.ssid_len = ICT_STRLEN(ssid);
    ICT_STRCPY(join_req.ssid, ssid);
    join_req.key_len = ICT_STRLEN(password);
    ICT_STRCPY(join_req.key, password);

    if (join_req.ssid_len) printf("ssid: %s\n", join_req.ssid);
    if (join_req.key_len) printf("pwd: %s\n", join_req.key);

    result = ict_api_join_handler(&join_req);
}

void wlan_operation_mode_station_stop()
{
    printf("[%s] called.\n", __func__);
    ict_api_disconnect_handler(NULL);
}

void wlan_operation_event_handler(T_MAC_EVENT *p_mac_event)
{
    switch(p_mac_event->code)
    {
        case ICT_HIF_CMD_ST_AP_START_IND:
            printf("I: AP START!!\n");
            break;

        case ICT_HIF_CMD_ST_AP_STOP_IND:
            printf("W: AP STOP!!\n");
            break;

        case ICT_HIF_CMD_ST_JOIN_IND:
            if(ict_api_join_state(p_mac_event->buf) == ICT_TRUE)
            {
                printf("I: ASSOCIATED!\n");
            }
            else
            {
                printf("W: DISCONNECT!\n");
            }          
            break;

        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            printf("E: DISASSOCIATED!!\n");
            break;
        
        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            printf("I: NETWORK_INFO_IND!!\n");
            {
                ICT_ST_NETWORK_INFO_IND_T *network_ind;
                network_ind = (ICT_ST_NETWORK_INFO_IND_T *)p_mac_event->buf;
                
                printf("IP       "IPSTR"\n", IP2STR(network_ind->ipaddr));
                printf("SUBNET   "IPSTR"\n", IP2STR(network_ind->subnet));
                printf("GATEWAY  "IPSTR"\n", IP2STR(network_ind->gateway));
                printf("DNS      "IPSTR"\n", IP2STR(network_ind->dns));
            }
            break;
    }
}

static void wlan_operation_task(void *arg)
{
    arg = arg;
    static int num;

    printf("\n");
    printf("==============================================\n");
    printf("=           wlan task started.               =\n");
    printf("==============================================\n");

    while(1)
    {
        /* TODO: User application ... */

        /* Operation Stop Test */
        if(0) // (num == 100)
        {
            if(opration_mode == WLAN_AP_MODE)
            {
                wlan_operation_mode_ap_stop();
            }
            else
            {
                wlan_operation_mode_station_stop();
            }
        }
        
        num++;
        ict_api_tn_task_sleep(10); // 100msec sleep
    }
    
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- wlan_operation\n\n");

    ict_cm_wlan_event_callback_register((void *)wlan_operation_event_handler);

    if(opration_mode == WLAN_AP_MODE)
    {
        wlan_operation_mode_ap_start();
    }
    else
    {
        wlan_operation_mode_station_start();
    }

    /* create task */
    if (p_wlan_task == ICT_NULL)
    {
        INT32 result;
        
        p_wlan_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_wlan_task == ICT_NULL)
        {
            printf("p_wlan_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_wlan_task, 0x00, sizeof(*p_wlan_task));
        ICT_MEMSET(wlan_task_stack, 0x00, sizeof(wlan_task_stack));

        result = ict_api_tn_task_create(p_wlan_task, "wlan", wlan_operation_task, NULL, &wlan_task_stack[WLAN_TASK_STACK_SIZE-1], WLAN_TASK_STACK_SIZE, WLAN_TASK_PRI);
        printf("ict_api_tn_task_create result(%d)\n", result);
    }    

    /* get MAC address */
    if (1)
    {
        UINT8 mac_addr[6];

        wlan_get_mac_address(mac_addr);        
    } 
    
    return;
}


