/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define GPIO_TASK_STACK_SIZE        (1024)
#define GPIO_TASK_PRI               (1)

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    LED_IDLE = 0,
    LED_OFF,
    LED_BLINK
}
GPIO_LED_STATE;

typedef enum
{
    BTN_FSM_IDLE = 0,
    BTN_FSM_CHECK_LONG_PRESS,
    BTN_FSM_CHECK_SHORT_PRESS,
    BTN_FSM_WAIT_UNPRESS
}
GPIO_BTN_FSM;

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_gpio_task = ICT_NULL;
DWALIGN OS_STK gpio_task_stack[GPIO_TASK_STACK_SIZE] XDWALIGN;

UINT8 led_port = GPIO_23; // GPIO_10 // UART1_RXD
UINT8 gpio_btn_port = GPIO_24; // GPIO_11 // UART1_TXD

static UINT32 btn_bnc_cnt = 0; /* bounce counter */
static UINT32 long_key_time_ms = 100;
static GPIO_BTN_FSM gpio_fsm = BTN_FSM_IDLE;
static GPIO_LED_STATE gpio_led_state = LED_IDLE;

static UINT32  led_blink_interval = 0;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void gpio_output_init(UINT8 gpio)
{
    ict_api_sys_gpio_set_pad(gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(gpio, 1);    /* 1: Output Mode, 0: Input Mode            */
    ict_api_sys_gpio_set_output(gpio, 1);
}

void gpio_input_init(UINT8 gpio)
{
    ict_api_sys_gpio_set_pad(gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(gpio, 0);    /* 1: Output Mode, 0: Input Mode            */
}

void gpio_button_proc (void)
{
    UINT32  curstate = 0;
    UINT16  out_val = 0; // Switch Debouncing

    curstate = ict_api_sys_gpio_get_input(gpio_btn_port);

    switch(gpio_fsm)
    {
        case BTN_FSM_IDLE:
            if(curstate == 0)
            {
                btn_bnc_cnt++;                
            
                if (btn_bnc_cnt >= long_key_time_ms)
                {
                    gpio_fsm = BTN_FSM_CHECK_LONG_PRESS;
                }
            }
            else
            {
                if(btn_bnc_cnt)
                {
                    gpio_fsm = BTN_FSM_CHECK_SHORT_PRESS;
                }
                
                btn_bnc_cnt = 0;
            }
            break;
            
        case BTN_FSM_CHECK_LONG_PRESS:
            gpio_fsm = BTN_FSM_WAIT_UNPRESS;
            gpio_led_state = LED_OFF;
            printf("T: Button State : LONG\n");
            break;    

        case BTN_FSM_CHECK_SHORT_PRESS:
            gpio_fsm = BTN_FSM_WAIT_UNPRESS;
            gpio_led_state = LED_BLINK;
            printf("T: Button State : SHORT\n");
            break;

        case BTN_FSM_WAIT_UNPRESS:
            if (curstate == 1)
            {
                gpio_fsm = BTN_FSM_IDLE;
                btn_bnc_cnt = 0;
            }
            break;
            
        default:
            break;
    }
}

void gpio_led_proc(void)
{
    UINT16  out_val = 0;
    
    switch(gpio_led_state)
    {
        case LED_IDLE:
            break;
            
        case LED_BLINK:
            if(led_blink_interval == 0)
            {
                out_val = (UINT16)ict_api_sys_gpio_get_output(led_port);
                ict_api_sys_gpio_set_output(led_port, ((~out_val) & 0x0001));
                led_blink_interval = 50;
            }
            else
            {
                led_blink_interval--;
            }
            break;
            
        case LED_OFF:
            ict_api_sys_gpio_set_output(led_port, 1);
            printf("T: LED Off\n");
            gpio_led_state = LED_IDLE;            
            break;
            
        default:
            break;
    }
}

static void gpio_task(void *arg)
{
    UINT16  out_val = 0;
    
    arg = arg;

    printf("\n");
    printf("==============================================\n");
    printf("=           gpio task started.               =\n");
    printf("==============================================\n");

    while(1)
    {
        ict_api_os_time_delay(1); // 10ms 
        gpio_button_proc();
        gpio_led_proc();
    }
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- gpio led blink\n\n");

    gpio_output_init(led_port);
    gpio_input_init(gpio_btn_port);

    /* create task */
    if (p_gpio_task == ICT_NULL)
    {
        INT32 result;

        p_gpio_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_gpio_task == ICT_NULL)
        {
            printf("p_gpio_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_gpio_task, 0x00, sizeof(*p_gpio_task));
        ICT_MEMSET(gpio_task_stack, 0x00, sizeof(gpio_task_stack));
        
        result = ict_api_tn_task_create(p_gpio_task, 
                                        "gpio",
                                        gpio_task, 
                                        NULL, 
                                        &gpio_task_stack[GPIO_TASK_STACK_SIZE-1], 
                                        GPIO_TASK_STACK_SIZE, 
                                        GPIO_TASK_PRI);
    }
    
    return;
}
