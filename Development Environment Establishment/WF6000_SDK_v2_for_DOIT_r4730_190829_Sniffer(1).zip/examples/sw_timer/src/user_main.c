/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: user_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define TMR_TASK_STACK_SIZE         (1024)
#define TMR_TASK_PRI                (1)

#define TASK_ID_SW_TMR              TASK_ID_API_CM
#define SW_EXT_TIMER_1MS            1

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

typedef enum
{
    SW_TIMER_ID_1MS,
    SW_TIMER_ID_2MS,
    SW_TIMER_ID_10MS,
    SW_TIMER_ID_100MS,
    SW_TIMER_ID_1000MS,
    SW_TIMER_ID_10000MS,
    SW_TIMER_ID_MAX = 32
} SW_TIMER_EVENT_ID;

#define SW_TIMER_1MS_TIME       1
#define SW_TIMER_2MS_TIME       2
#define SW_TIMER_10MS_TIME      10
#define SW_TIMER_100MS_TIME     100
#define SW_TIMER_1000MS_TIME    1000
#define SW_TIMER_10000MS_TIME   10000

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

extern OS_FLAG_GRP *    cm_event_group;
extern SW_TIMER_CNTX    cm_ext_timer;
extern SW_TIMER         cm_ext_timer_list[CM_EXT_TIMER_MAX];

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_tmr_task = ICT_NULL;
DWALIGN OS_STK tmr_task_stack[TMR_TASK_STACK_SIZE] XDWALIGN;

UINT8 tmr1_test_gpio = GPIO_23;
UINT8 tmr2_test_gpio = GPIO_24;



/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

void sw_tmr_test_gpio_init(void)
{
    ict_api_sys_gpio_set_pad(tmr1_test_gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(tmr1_test_gpio, 1);    /* 1: Output Mode, 0: Input Mode            */
    ict_api_sys_gpio_set_output(tmr1_test_gpio, 1);

    ict_api_sys_gpio_set_pad(tmr2_test_gpio, 1);          /* 1: GPIO Enable, 0: GPIO Disable          */
    ict_api_sys_gpio_set_direction(tmr2_test_gpio, 1);    /* 1: Output Mode, 0: Input Mode            */
    ict_api_sys_gpio_set_output(tmr2_test_gpio, 1);
}

void sw_tmr_event_handler (void *pTmrCntx, UINT32 timerId)
{
    UINT16  out_val = 0;
    
    switch(timerId)
    {
        case SW_TIMER_ID_1MS:
            out_val = (UINT16)ict_api_sys_gpio_get_output(tmr1_test_gpio);
            ict_api_sys_gpio_set_output(tmr1_test_gpio, ((~out_val) & 0x0001));
            break;
        case SW_TIMER_ID_2MS:
            out_val = (UINT16)ict_api_sys_gpio_get_output(tmr2_test_gpio);
            ict_api_sys_gpio_set_output(tmr2_test_gpio, ((~out_val) & 0x0001));
            break;
        case SW_TIMER_ID_10MS:
            break;

        case SW_TIMER_ID_100MS:
            break;

        case SW_TIMER_ID_1000MS:
            ict_api_ext_sw_timer_stop(&cm_ext_timer, SW_TIMER_ID_1000MS);
            printf("### SW Timer Event 1000ms ###\n");
            ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_1000MS, ICT_TRUE, SW_TIMER_1000MS_TIME, sw_tmr_event_handler);
            break;
            
        case SW_TIMER_ID_10000MS:
            break;

        default:
            break;
    }
}

void sw_tmr_init(void)
{
    UINT8	err;

	/* Create Event Flag Group */
    if(cm_event_group == NULL)
    {
        cm_event_group = ict_api_os_flag_create(0x00, &err);        
    }
    
    ict_api_ext_hw_timer_start(SW_EXT_TIMER_1MS);
    ict_api_ext_sw_timer_init (&cm_ext_timer, cm_ext_timer_list, SW_TIMER_ID_MAX, cm_event_group, TASK_ID_SW_TMR);

    sw_tmr_test_gpio_init();
}

static void sw_tmr_task(void *arg)
{
    UINT16  out_val = 0;
    UINT32  run_cnt = 0;
    
    arg = arg;

    printf("\n");
    printf("==============================================\n");
    printf("=           sw timer task started.           =\n");
    printf("==============================================\n");

    while(1)
    {
        ict_api_os_time_delay(50); // 500ms 
        printf("= sw timer task running : %d =\n", run_cnt++);
    }
}

void user_start()
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));
    
    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-- sw timer\n\n");
    
    sw_tmr_init();

    ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_1MS, ICT_TRUE, SW_TIMER_1MS_TIME, sw_tmr_event_handler);
    ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_2MS, ICT_TRUE, SW_TIMER_2MS_TIME, sw_tmr_event_handler);
    //ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_10MS, ICT_TRUE, SW_TIMER_10MS_TIME, sw_tmr_event_handler);
    //ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_100MS, ICT_TRUE, SW_TIMER_100MS_TIME, sw_tmr_event_handler);
    ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_1000MS, ICT_TRUE, SW_TIMER_1000MS_TIME, sw_tmr_event_handler);
    //ict_api_ext_sw_timer_start(&cm_ext_timer, SW_TIMER_ID_10000MS, ICT_TRUE, SW_TIMER_10000MS_TIME, sw_tmr_event_handler);

    /* create task */
    if (p_tmr_task == ICT_NULL)
    {
        INT32 result;

        p_tmr_task = ict_api_malloc(sizeof(TN_TCB));
        if (p_tmr_task == ICT_NULL)
        {
            printf("p_tmr_task malloc failed.\n");
            return;
        }
        
        ICT_MEMSET(p_tmr_task, 0x00, sizeof(*p_tmr_task));
        ICT_MEMSET(tmr_task_stack, 0x00, sizeof(tmr_task_stack));
        
        result = ict_api_tn_task_create(p_tmr_task, 
                                        "sw_timer",
                                        sw_tmr_task, 
                                        NULL, 
                                        &tmr_task_stack[TMR_TASK_STACK_SIZE-1], 
                                        TMR_TASK_STACK_SIZE, 
                                        TMR_TASK_PRI);
    }
    
    return;
}


