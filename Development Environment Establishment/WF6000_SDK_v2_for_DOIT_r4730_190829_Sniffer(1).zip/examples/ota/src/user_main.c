/*--------------------------------------------------------------------------
/   Project name    : I&C Technology Alphabeam Wi-Fi
/   Copyright       : I&C Technology, All rights reserved.
/   File name       : user_main.c
/   Description     :
/
/
/
/
/   Name        Date        Action
/
---------------------------------------------------------------------------*/


/*
******************************************************************************
*   INCLUDE
******************************************************************************
*/

#include "ict_cm_globals.h"
#include "user_config.h"


/*
******************************************************************************
*   LOCAL CONSTANTS
******************************************************************************
*/

#define OTA_TASK_STACK_SIZE     (1024)
#define OTA_TASK_PRI            (1)

#define TASK_ID_OTA             TASK_ID_API_CM


/*
******************************************************************************
*   LOCAL DATA TYPES
******************************************************************************
*/


/*
******************************************************************************
*   GLOBAL VARIABLES
******************************************************************************
*/

extern OS_FLAG_GRP     *cm_event_group;


/*
******************************************************************************
*   LOCAL VARIABLES
******************************************************************************
*/

TN_TCB *p_ota_task = ICT_NULL;
DWALIGN OS_STK ota_task_stack[OTA_TASK_STACK_SIZE] XDWALIGN;

static UINT32 ota_done_flag = OTA_UPDATE_ST_INIT;


/*
******************************************************************************
*   LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


/*
******************************************************************************
*   FUNCTIONS
******************************************************************************
*/

int http_update_ota(char *ip, int port, char *filename)
{
    int32_t ret = ICT_ERR;
    char server_url[128] = {0x00, };
    uint32_t url_len = 0;

    if (ip == ICT_NULL || port == 0 || filename == ICT_NULL)
    {
        printf("OTA wrong parameter.\n");
        return ICT_ERR;
    }

    ret = ict_api_ota_set_init(filename);

    if (ret != ICT_NO_ERR)
    {
        printf("OTA wrong parameter. (%d)\n", ret);
        return ICT_ERR;
    }

    ICT_MEMSET(server_url, 0x00, sizeof(server_url));
    url_len = ICT_SPRINTF(server_url, "http://%s:%u", ip, port);
    server_url[url_len++] = '\0';

    printf("OTA url_len(%d) url(%s)\n", url_len, server_url);

    ota_done_flag = OTA_UPDATE_ST_ON_GOING;
    http_ota_callback = (void *) http_ota_process;

    ret = ict_api_ota_request((UINT8 *) server_url, url_len);

    if (ret != ICT_NO_ERR)
    {
        http_ota_callback = ICT_NULL;
        printf("OTA request failed. (%d)\n", ret);
        return ICT_ERR;
    }

    while (1)
    {
        if (ota_done_flag != OTA_UPDATE_ST_ON_GOING)
        {
            break;
        }

        ict_api_tn_task_sleep(10);
    }

    http_ota_callback = ICT_NULL;

    if (ota_done_flag != OTA_UPDATE_ST_FIN_SUCCESS)
    {
        printf("OTA update finished unsuccessfully. (%d)\n\n", ota_done_flag);
        ota_done_flag = OTA_UPDATE_ST_INIT;
        return ICT_ERR;
    }

    ret = ict_api_ota_process_update_finished();

    ota_done_flag = OTA_UPDATE_ST_INIT;

    if (ret != ICT_NO_ERR)
    {
        printf("OTA update failed. (%d)\n\n", ret);
        return ICT_ERR;
    }
    else
    {
        printf("OTA update succeeded. %d)\n\n", ret);
    }

    return ICT_NO_ERR;
}

void http_ota_process(uint32_t event_type, uint8_t *buf, uint32_t len)
{
    UINT32 *ota_update_fin_reason = ICT_NULL;

    if (event_type == ICT_HIF_CMD_ST_OTA_UPDATE_IND && len)
    {
        ict_api_ota_process_update(buf, len);
    }
    else if (event_type == ICT_HIF_CMD_ST_OTA_UPDATE_FIN_IND)
    {
        if (buf == ICT_NULL)
        {
            printf("Unexpected ICT_HIF_CMD_ST_OTA_UPDATE_FIN_IND\n");
            ota_done_flag = OTA_UPDATE_ST_FIN_FAIL;
        }
        else
        {
            ota_update_fin_reason = (UINT32 *) buf;
            ota_done_flag = *ota_update_fin_reason;
            printf("OTA update finished. (%d)\n", ota_done_flag);
        }
    }
}

static void ota_task(void *arg)
{
    UINT32  run_cnt = 0;

    printf("\n");
    printf("==============================================\n");
    printf("=              OTA task started.             =\n");
    printf("==============================================\n");

    while (1)
    {
        printf("= OTA task running : %d =\n", run_cnt++);

        if (ota_done_flag == OTA_UPDATE_ST_INIT)
        {
            printf("Try OTA firmware download\n");
            http_update_ota("12.34.56.78", 8888, "ota_firmware.bin");
        }
        else
        {
            printf("OTA firmware downloading...\n");
        }

        ict_api_tn_task_sleep(1000);    // 10s
    }
}

void user_start(void)
{
    ict_api_tn_task_sleep(10);

    /* The default baudrate of UART0 is 8000000. */
    /* The baudrate of UART0 can be changed to 115200 or 230400, ..., 8000000 */
//    ict_api_uart_change_baudrate (UART0, 8000000, fMACWLEN(UART_WORD_LEN_8BITS));

    printf("\n");
    printf("=== Current baudrate of UART%d : %d ===\n", UART0, ict_api_uart_get_baudrate(UART0));  
    printf("**********************************************\n");
    printf("*              USER started.                 *\n");
    printf("**********************************************\n");
    printf("-> OTA\n\n");

    /* Create task */
    if (p_ota_task == ICT_NULL)
    {
        INT32 result = 0;

        p_ota_task = ict_api_malloc(sizeof(TN_TCB));

        if (p_ota_task == ICT_NULL)
        {
            printf("p_ota_task malloc failed.\n");
            return;
        }

        ICT_MEMSET(p_ota_task, 0x00, sizeof(*p_ota_task));
        ICT_MEMSET(ota_task_stack, 0x00, sizeof(ota_task_stack));

        result = ict_api_tn_task_create(p_ota_task,
                                        "OTA",
                                        ota_task,
                                        NULL,
                                        &ota_task_stack[OTA_TASK_STACK_SIZE - 1],
                                        OTA_TASK_STACK_SIZE,
                                        OTA_TASK_PRI);
    }

    return;
}
