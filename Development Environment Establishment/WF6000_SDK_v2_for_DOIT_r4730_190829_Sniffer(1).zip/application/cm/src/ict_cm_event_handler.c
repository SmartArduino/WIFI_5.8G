/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_event_handler.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
wlan_operation_event_handler_t p_wlan_callback = ICT_NULL;
wlan_scan_event_handler_t p_scan_callback = ICT_NULL;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/
    
#if defined (FEATURE_HTTPC_SUPP)
#if defined (FEATURE_OTA_SUPP)
void (*http_ota_callback)(UINT32 event_type, UINT8 *buf, UINT32 len) = ICT_NULL;
#endif /* FEATURE_OTA_SUPP */
#endif /* FEATURE_HTTPC_SUPP */

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_cm_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_cm_initialization(UINT32 boot_up)
{
    if(boot_up == ICT_TRUE)
    {
        ict_cm_timer_initialization();
    }
}

/*****************************************************************************
** Function name: ict_cm_event_cmd_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_cm_wlan_event_callback_register(wlan_operation_event_handler_t p_callback)
{
    p_wlan_callback = p_callback;
}

void ict_cm_wlan_scan_event_callback_register(wlan_scan_event_handler_t p_callback)
{
    p_scan_callback = p_callback;
}

static UINT32 ict_cm_event_cmd_handler(T_MAC_EVENT * p_mac_event)
{
    UINT32 rtn_val = ICT_FALSE;
    
    switch (p_mac_event->code)
    {

        case ICT_HIF_CMD_ST_DEVICE_READY_IND:
            if (ict_api_debug_get_poll_mode())
                ict_api_debug_set_poll_mode(ICT_FALSE);

            user_start();            
            break;

        case ICT_HIF_CMD_ST_AP_START_IND:
        case ICT_HIF_CMD_ST_AP_STOP_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_AP_START_IND/ICT_HIF_CMD_ST_AP_STOP_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_JOIN_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_JOIN_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_DISCONNECTED_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_DISCONNECTED_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_NETWORK_INFO_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_NETWORK_INFO_IND (no callback)\n");
            }
            break;            

        case ICT_HIF_CMD_ST_SCAN_IND:
            if (p_scan_callback != ICT_NULL)
            {
                p_scan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_SCAN_IND (no callback)\n");                
            }
            break;

        case ICT_HIF_CMD_ST_SCAN_RST_IND:
            if (p_scan_callback != ICT_NULL)
            {
                p_scan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_SCAN_RST_IND (no callback)\n");                
            }
            break;

        case ICT_HIF_CMD_ST_SOCKET_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_SOCKET_IND (no callback)\n");
            }
            break;            

        case ICT_HIF_CMD_ST_TCP_DISCONNECT_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_DISCONNECT_IND (no callback)\n");
            }
            break;
        case ICT_HIF_CMD_ST_STA_ASSOCIATED_IND:
            printf("W: ICT_HIF_CMD_ST_STA_ASSOCIATED_IND (no callback)\n");
            break;

        case ICT_HIF_CMD_ST_STA_DISASSOCIATED_IND:
            printf("W: ICT_HIF_CMD_ST_STA_DISASSOCIATED_IND (no callback)\n");
            break;
            
#if defined (CONFIG_WPS)            
        case ICT_HIF_CMD_ST_WPS_RESULT_IND:
            {
                ICT_ST_WPS_RESULT_IND_T *p_ind = (ICT_ST_WPS_RESULT_IND_T *)(p_mac_event->buf);
                
                printf("W: ICT_HIF_CMD_ST_WPS_RESULT_IND (%d)\n", p_ind->result);
                
                if (p_ind->result== API_WPS_IND_SUCCESS)
                {                    
                    if (p_ind->ssid_len)
                        printf("[WPS] ssid(%d) (%s)\n", p_ind->ssid_len, p_ind->ssid);
                    
                    if (p_ind->psk_len)
                        printf("[WPS] passphrase(%d) (%s)\n", p_ind->psk_len, p_ind->psk);
                }
            }
            break;
            
#endif /* CONFIG_WPS */

        case ICT_HIF_CMD_ST_PING_REPLY_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                //printf("Event: ICT_HIF_CMD_ST_PING_REPLY_IND\n");
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_PING_REPLY_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_PING_RESULT_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                //printf("Event: ICT_HIF_CMD_ST_PING_RESULT_IND\n");
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_PING_RESULT_IND (no callback)\n");
            }
            break;

#if defined (FEATURE_HTTPC_SUPP)
#if defined (FEATURE_OTA_SUPP)
        case ICT_HIF_CMD_ST_OTA_UPDATE_IND:
            if (http_ota_callback)
            {
                http_ota_callback(p_mac_event->code, p_mac_event->buf, p_mac_event->len);
            }
            break;

        case ICT_HIF_CMD_ST_OTA_UPDATE_FIN_IND:
            if (http_ota_callback)
            {
                http_ota_callback(p_mac_event->code, p_mac_event->buf, p_mac_event->len);
            }
            break;
#endif /* FEATURE_OTA_SUPP */
#endif /* FEATURE_HTTPC_SUPP */

#if defined (FEATURE_TCP_SSL_SUPP)
        case ICT_HIF_CMD_ST_TCP_SSL_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_TCP_SSL_RECV_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_RECV_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_CLOSE_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_CLOSE_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_SVR_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_RECV_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_SVR_RECV_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_CLOSE_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_SVR_CLOSE_IND (no callback)\n");
            }
            break;

        case ICT_HIF_CMD_ST_TCP_SSL_SVR_ACCEPTED_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_TCP_SSL_SVR_ACCEPTED_IND (no callback)\n");
            }
            break;
#endif
           
#if defined (FEATURE_HTTPC_SUPP)
        case ICT_HIF_CMD_ST_HTTP_CONTROL_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_HTTP_CONTROL_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_HTTP_BODY_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_HTTP_BODY_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_HTTP_RESPONSECODE_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_HTTP_RESPONSECODE_IND (no callback)\n");
            }
            break;
#endif

#if defined(FEATURE_MOTA_SUPP)
        case ICT_HIF_CMD_ST_MOTA_UPDATE_IND:
#if defined(FEATURE_FATFS_GENERIC_API)
            ict_api_fs_mcu_ota_fw_download_process(p_mac_event->buf, p_mac_event->len);
#else
            if (p_wlan_callback != ICT_NULL)
            {
                //printf("Event: ICT_HIF_CMD_ST_MOTA_UPDATE_IND\n");
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MOTA_UPDATE_IND (no callback)\n");
            }
#endif /* FEATURE_FATFS_GENERIC_API */
            break;

        case ICT_HIF_CMD_ST_MOTA_UPDATE_FIN_IND:
#if defined(FEATURE_FATFS_GENERIC_API)
            ict_api_fs_mcu_ota_fw_download_finish();
#else
            if (p_wlan_callback != ICT_NULL)
            {
                //printf("Event: ICT_HIF_CMD_ST_MOTA_UPDATE_FIN_IND\n");
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MOTA_UPDATE_FIN_IND (no callback)\n");
            }
#endif /* FEATURE_FATFS_GENERIC_API */
            break;
#endif /* FEATURE_MOTA_SUPP */

#if defined(FEATURE_MQTT_SUPP)
        case ICT_HIF_CMD_ST_MQTT_PUB_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_PUB_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_SUB_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_SUB_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_PUB_RECV_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_PUB_RECV_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_SUB_RECV_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_SUB_RECV_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_IND (no callback)\n");
            }
            break;
            
        case ICT_HIF_CMD_ST_MQTT_RECV_IND:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_MQTT_RECV_IND (no callback)\n");
            }
            break;
#endif /* FEATURE_MQTT_SUPP */

        default:
            printf("E: [%s] event(%08X:%d) received. (no callback)\n", __func__, p_mac_event->code, p_mac_event->code);
            break;
    }

    return rtn_val;
}

/*****************************************************************************
** Function name: ict_cm_event_data_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
static UINT32 ict_cm_event_data_handler(T_MAC_EVENT * p_mac_event)
{
    INT32 rtn_val = ICT_FALSE;
    switch (p_mac_event->code)
    {
        case ICT_HIF_DATA_RX:
            if (p_wlan_callback != ICT_NULL)
            {
                p_wlan_callback(p_mac_event);
            }
            else
            {
                printf("W: ICT_HIF_CMD_ST_AP_START_IND/ICT_HIF_CMD_ST_AP_STOP_IND (no callback)\n");
            }
            //rtn_val = ict_cm_app_rcvd_data_hif_ind(p_mac_event->buf, p_mac_event->len);
            break;
            
        default:
            break;
    }

    return rtn_val;
}

/*****************************************************************************
** Function name: ict_cm_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT32 ict_cm_event_handler(T_MAC_EVENT *p_mac_event)
{
    if ((ICT_HIF_CMD_GROUP  <= p_mac_event->code) && (p_mac_event->code < ICT_HIF_CMD_MAX ))
    {
        return (ict_cm_event_cmd_handler(p_mac_event));
    }
    else if ((ICT_HIF_DATA_MIN <= p_mac_event->code) && (p_mac_event->code < ICT_HIF_DATA_MAX))
    {
        return (ict_cm_event_data_handler(p_mac_event));
    }
    else if (p_mac_event->code == ICT_HIF_ETC_TASK_DELETE_REQUEST)
    {
        TN_TCB *task;
        int result;
        UINT32 ptr;
        UINT32 stack_addr;

        if (p_mac_event->buf != ICT_NULL)
        {
            ICT_MEMCPY(&ptr, p_mac_event->buf, 4);
            task = (TN_TCB *) (ptr);

            stack_addr = (UINT32) task->stk_start - (task->stk_size * sizeof(OS_STK)) + 4;

            result = ict_api_tn_task_delete(task);
            APP_PRINTF("W: [%s] task (%08X) delete result(%d)\n", __func__, ptr, result);

            if (result == ICT_NO_ERR)
            {
                if (stack_addr)
                {
                    APP_PRINTF("W: addr: %08X\n", stack_addr);

                    if (stack_addr != ICT_NULL)
                    {
                        ict_api_mfree((void *) stack_addr);
                    }
                }

                return ICT_TRUE;
            }
            else
            {
                return ICT_FALSE;
            }
        }
    }

    return ICT_TRUE;
}

/*****************************************************************************
** Function name: ict_cm_timer_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_cm_timer_event_handler (void *pTmrCntx, UINT32 timerId)
{
    INT32 err = ICT_OK;
    
    switch(timerId)
    {
        default:
            break;
    }
}

/*****************************************************************************
** Function name: ict_cm_ext_timer_event_handler
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_cm_ext_timer_event_handler (void *pTmrCntx, UINT32 timerId)
{
    //INT32 err = ICT_OK;
    
    switch(timerId)
    {
        default:
            break;
    }
}

#endif /* HOST_STDA_CM_INTERWORKING */

