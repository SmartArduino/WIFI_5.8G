/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_main.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/
#include "ict_cm_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

#define UART0_DM_ENABLE

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/
    
#if defined(FEATURE_OPERATION_MODE)
extern UINT32 b_sys_op_mode_test;
#endif

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/
DWALIGN OS_STK          cm_task_stack[SIZE_OF_CM_TASK_STACK] XDWALIGN;

DWALIGN OS_FLAG_GRP *   cm_event_group XDWALIGN;
DWALIGN T_LIST          cm_primitive_queue XDWALIGN;

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

static void ict_cm_task_main(void * pdata);

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_cm_task_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_cm_task_initialization(void)
{
	UINT8	err;

	/* Create Event Flag Group */
	cm_event_group = ict_api_os_flag_create(0x00, &err);

	/* Create Primitive Queue */
	ict_api_os_primitive_queue_create(&cm_primitive_queue);
    ict_api_sw_timer_init (&cm_timer, cm_timer_list, CM_TIMER_MAX, 10, cm_event_group);
    ict_api_ext_sw_timer_init (&cm_ext_timer, cm_ext_timer_list, CM_EXT_TIMER_MAX, cm_event_group, TASK_PRI_API_CM);

#if defined (UART0_DM_ENABLE)
// UART0 DM enable
    ict_api_debug_dm_enable(ICT_TRUE, ICT_NULL, ICT_NULL);
    ict_api_debug_set_fd_enable(0x0);
    APP_PRINTF("***** ALPHABEAM *****\n");
#endif    

	/* Create the CM Task */
    ict_api_os_task_create_ext(ict_cm_task_main,
                    (void *)0,
                    &cm_task_stack[SIZE_OF_CM_TASK_STACK - 1],
                    TASK_PRI_API_CM, 
                    TASK_ID_API_CM, 
                    &cm_task_stack[0], 
                    SIZE_OF_CM_TASK_STACK, 
                    (void *)0, 
                    0);

	ict_api_os_task_name_set(TASK_PRI_API_CM, (UINT8 *)"cm", &err);

}

/*****************************************************************************
** Function name: ict_cm_main_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
static void ict_cm_main_initialization(void)
{
    /* Create timer */
   
    /* Initialize */
    ict_cm_initialization(ICT_TRUE);

    APP_PRINTF("%s\n", __func__);
}

/*****************************************************************************
** Function name: ict_cm_task_main
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
static void ict_cm_task_main(void * pdata)
{
    UINT8           err;
    OS_FLAGS        masked_event;
    OS_FLAGS        waiting_event;
    T_MAC_EVENT     *p_mac_event;

   	/* Prevent compiler warning*/
	pdata = pdata;

	waiting_event = (EVENT_MASK_PRIMITIVE
                    |EVENT_MASK_TIMER
                    );

	/* Initialize CM task */
	ict_cm_main_initialization();

	/* Set SME ACK */
	ict_api_task_ready();

	while (ICT_TRUE)
	{
        masked_event = ict_api_os_flag_pend(cm_event_group, waiting_event, (OS_FLAG_WAIT_SET_ANY + OS_FLAG_CONSUME), 1, &err);
        
		if (masked_event & EVENT_MASK_PRIMITIVE)
		{
			while (ict_api_os_primitive_queue_empty(&cm_primitive_queue) == ICT_FALSE)
			{
				p_mac_event = (T_MAC_EVENT *)ict_api_task_dequeue_primitive(&cm_primitive_queue);
                if(p_mac_event)
                {
#if defined(FEATURE_OPERATION_MODE)
                    if (b_sys_op_mode_test)
                    {
                        if (p_mac_event->code == ICT_HIF_CMD_ST_DEVICE_READY_IND)
                        {
                            ict_api_set_test_mode(ICT_TRUE);

                            APP_PRINTF("\n\n");
                            APP_PRINTF("-----------------------------------------\n");
                            APP_PRINTF("                Test Mode                \n");
                            APP_PRINTF("-----------------------------------------\n\n");
                        }
                    }
                    else
                    {
                        ict_cm_event_handler(p_mac_event);
                    }
#else
                    ict_cm_event_handler(p_mac_event);
#endif
                    ict_api_task_primitive_receive(p_mac_event);
                }
			}
		}

        // Message From CM Timer
		if (masked_event & EVENT_MASK_TIMER)
		{
            //APP_PRINTF("CM EVENT_MASK_TIMER \n");
            ict_api_sw_timer_task_proc (&cm_timer);
            ict_api_ext_sw_timer_task_proc(&cm_ext_timer);
		}
	}
}

#endif /* HOST_STDA_CM_INTERWORKING */

