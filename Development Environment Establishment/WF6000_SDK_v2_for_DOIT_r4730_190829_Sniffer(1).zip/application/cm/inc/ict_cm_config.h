/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_config.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_CM_CONFIG_H__)
#define __ICT_CM_CONFIG_H__

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/

/* For TEST */
//#define FEATURE_CM_TIMER_TEST
//#define FEATURE_CM_EXT_TIMER_TEST
//#define FEATURE_CM_GPIO_TEST
//#define FEATURE_CM_UART0_GPIO_TEST
//define FEATURE_CM_RS485_TEST
//#define FEATURE_CM_HEARTBEAT_TEST
//#define FEATURE_CM_AES_TEST
#if defined(FEATURE_FILE_SYSTEM_FATFS)
#define FEATURE_FILE_SYSTEM_FATFS_TEST
#endif
#if defined (FEATURE_JSON_PARSER)
#define FEATURE_JSON_PARSER_TEST
#endif

/* Use UART interface */
#if defined (FEATURE_USE_UART0_CM) || defined (FEATURE_USE_UART1_CM) || defined (FEATURE_USE_UART1_INTP) || defined (FEATURE_USE_UART2_CM) || defined (FEATURE_USE_UART2_INTP)
#define FEATURE_CM_APP_UART
#define FEATURE_CM_SHELL
#endif

//#define FEATURE_CM_APP_AUTO_START_STA
//#define FEATURE_CM_APP_AUTO_START_AP
#define FEATURE_CM_APP_LOOPBACK

/* Set one of them for an auto connection. */
#define AUTO_CONNECT_SPECIFIC_AP_ENABLE     0   // enable auto-connect to specific AP
#define AUTO_CONNECT_WPS_PBC_AP_ENABLE      1   // enable auto-connect using WPS PBC method
#define AUTO_CONNECT_WPS_PIN_AP_ENABLE      2   // enable auto-connect using WPS PIN method
#define AUTO_CONNECT_P2P_ENABLE             3   // enable auto-connect using P2P
#define AUTO_CONNECT_NONE                   4

#define USER_CHANNEL_ENABLE         1   // enable user definition channel 

/* AP mode ip setting */
#define ICT_AP_IP_ADDR0             192
#define ICT_AP_IP_ADDR1             168
#define ICT_AP_IP_ADDR2             43
#define ICT_AP_IP_ADDR3             1

#define ICT_AP_GW_ADDR0             ICT_AP_IP_ADDR0
#define ICT_AP_GW_ADDR1             ICT_AP_IP_ADDR1
#define ICT_AP_GW_ADDR2             ICT_AP_IP_ADDR2
#define ICT_AP_GW_ADDR3             ICT_AP_IP_ADDR3

#define ICT_AP_NETMASK_ADDR0        255
#define ICT_AP_NETMASK_ADDR1        255
#define ICT_AP_NETMASK_ADDR2        255
#define ICT_AP_NETMASK_ADDR3        0

#define ICT_AP_LEASE_IP_MIN         20
#define ICT_AP_LEASE_IP_MAX         200

/* STA DHCP setting */
#define ICT_DHCP_MODE               ICT_TRUE        // dhcp mode (0: manual or 1:dhcp)

/* STA mode manual mode ip setting */
#define ICT_IP_ADDR0                10
#define ICT_IP_ADDR1                0

#define ICT_GW_ADDR0                ICT_IP_ADDR0
#define ICT_GW_ADDR1                ICT_IP_ADDR1
#define ICT_GW_ADDR2                0
#define ICT_GW_ADDR3                1

#define ICT_NETMASK_ADDR0           255
#define ICT_NETMASK_ADDR1           255
#define ICT_NETMASK_ADDR2           0
#define ICT_NETMASK_ADDR3           0

#define ICT_DNS_ADDR0               164
#define ICT_DNS_ADDR1               124
#define ICT_DNS_ADDR2               101
#define ICT_DNS_ADDR3               2

#define ICT_BSS_TYPE                BSS_TYPE_INFRASTRUCTURE     // operation type

#define ICT_JOIN_SSID               ""                // specific ssid to join

#define ICT_PSK                     "12345678"                  // passphrase

/* security setup */
#define ICT_AUTH_TYPE               MIB_AUTH_OPEN_SYSTEM
#define ICT_AUTH_ENC_TYPE           AUTH_ENC_TYPE_NONE
#define ICT_PAIRWISE_CIPHER         PAIRWISE_CIPHER_CCMP
#define ICT_GROUP_CIPHER            GROUP_CIPHER_CCMP

/* pin number displayed from AP */
#define ICT_WPS_PIN_NUMBER          "87654321"

/* tcp loopback test parameters */
#define ICT_TCP_LOCAL_PORT          50010
#define ICT_TCP_REMOTE_PORT         50020
#define ICT_TCP_REMOTE_ADDR0        192
#define ICT_TCP_REMOTE_ADDR1        168
#define ICT_TCP_REMOTE_ADDR2        1
#define ICT_TCP_REMOTE_ADDR3        109

/* udp loopback test parameters */
#define ICT_UDP_LOCAL_PORT          50030
#define ICT_UDP_REMOTE_PORT         50040
#define ICT_UDP_REMOTE_ADDR0        192
#define ICT_UDP_REMOTE_ADDR1        168
#define ICT_UDP_REMOTE_ADDR2        1
#define ICT_UDP_REMOTE_ADDR3        109

#if defined (FEATURE_CM_GPIO_TEST)
#define ICT_GPIO_IN                 GPIO_14
#define ICT_GPIO_OUT                GPIO_15
#endif

#if defined (FEATURE_CM_UART0_GPIO_TEST)
#define ICT_GPIO_IN                 GPIO_8  // UART_0_TX_GPIO
#define ICT_GPIO_OUT                GPIO_9  // UART_0_RX_GPIO
#endif

/*
******************************************************************************
*	MACRO
******************************************************************************
*/

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*   FUNCTIONS
******************************************************************************
*/

#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_CM_CONFIG_H__ */

