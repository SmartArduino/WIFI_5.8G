/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_cm_timer.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if !defined(__ICT_CM_TIMER_H__)
#define __ICT_CM_TIMER_H__

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/
#define CM_TIMER_START_TIME         500
#define CM_TIMER_SCAN_TIME          1000
#define CM_TIMER_WPS_TIME           500
#define CM_TIMER_LOOPBACK_TEST_TIME 10
#define CM_TIMER_UART_TRAFFIC_TIME  1000
#define CM_TIMER_PING_REQ_TIME      1000
#if defined (FEATURE_CM_TIMER_TEST)
#define CM_TIMER_TEST_10MS_TIME     10
#define CM_TIMER_TEST_100MS_TIME    100
#define CM_TIMER_TEST_1000MS_TIME   1000
#endif

#if defined (FEATURE_CM_EXT_TIMER_TEST)
#define CM_EXT_TIMER_TEST_1MS_TIME      1
#define CM_EXT_TIMER_TEST_10MS_TIME     10
#define CM_EXT_TIMER_TEST_100MS_TIME    100
#define CM_EXT_TIMER_TEST_1000MS_TIME   1000
#define CM_EXT_TIMER_TEST_1000000MS_TIME 1000000
#endif

#if defined (FEATURE_CM_HEARTBEAT_TEST)
#define CM_HEARTBEAT_TEST_TIME   10000
#endif

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/
typedef enum
{
    CM_TIMER_OPERATION_START,
    CM_TIMER_SCAN,
#if defined (CONFIG_WPS)
    CM_TIMER_WPS_PBC,
    CM_TIMER_WPS_PIN,
    CM_TIMER_WPS_CANCEL,
#endif
    CM_TIMER_LOOPBACK_TEST,
    CM_TIMER_UART_TRAFFIC,
    CM_TIMER_PING_REQ,
#if defined (FEATURE_CM_TIMER_TEST)
    CM_TIMER_TEST_10MS,
    CM_TIMER_TEST_100MS,
    CM_TIMER_TEST_1000MS,
#endif
#if defined (FEATURE_CM_HEARTBEAT_TEST)
    CM_TIMER_HEARTBEAT_TEST,
#endif
    CM_TIMER_MAX
}ICT_CM_TASK_TIMER;

typedef enum
{
#if defined (FEATURE_CM_EXT_TIMER_TEST)
    CM_EXT_TIMER_TEST_1MS,
    CM_EXT_TIMER_TEST_10MS,
    CM_EXT_TIMER_TEST_100MS,
    CM_EXT_TIMER_TEST_1000MS,
    CM_EXT_TIMER_TEST_1000000MS,
#endif
    CM_EXT_TIMER_MAX = 32
}ICT_CM_TASK_EXT_TIMER;

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/
extern SW_TIMER_CNTX   cm_timer;
extern SW_TIMER        cm_timer_list[CM_TIMER_MAX];

extern SW_TIMER_CNTX   cm_ext_timer;
extern SW_TIMER        cm_ext_timer_list[CM_EXT_TIMER_MAX];

/*
******************************************************************************
*   FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_cm_timer_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_timer_initialization(void);

/*****************************************************************************
** Function name: ict_cm_timer_get_status
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_timer_get_status(UINT32 timerId);

/*****************************************************************************
** Function name: ict_cm_timer_get_expire_cnt
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_timer_get_expire_cnt(UINT32 timerId);

/*****************************************************************************
** Function name: ict_cm_ext_timer_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_ext_timer_initialization(void);

/*****************************************************************************
** Function name: ict_cm_ext_timer_get_status
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_ext_timer_get_status(UINT32 enabled_timer);

/*****************************************************************************
** Function name: ict_cm_ext_timer_get_expire_cnt
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT32 ict_cm_ext_timer_get_expire_cnt(UINT32 enabled_timer);


/*****************************************************************************
** Function name: ict_cm_app_timer_create
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT8 ict_cm_app_timer_create(APP_TIMER_HANDLER *timer_t, const char *name, UINT32 reload, UINT32 interval, void* callback);

/*****************************************************************************
** Function name: ict_cm_app_timer_delete
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT8 ict_cm_app_timer_delete(APP_TIMER_HANDLER *timer_t);

/*****************************************************************************
** Function name: ict_cm_app_timer_start
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT8 ict_cm_app_timer_start(APP_TIMER_HANDLER *timer_t);

/*****************************************************************************
** Function name: ict_cm_app_timer_stop
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
extern UINT8 ict_cm_app_timer_stop(APP_TIMER_HANDLER *timer_t);

#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_CM_TIMER_H__ */

