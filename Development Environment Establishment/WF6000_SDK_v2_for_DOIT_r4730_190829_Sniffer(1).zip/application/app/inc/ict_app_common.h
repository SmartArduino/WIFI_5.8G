/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_common.h
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/


#ifndef __ICT_APP_COMMON_H__
#define __ICT_APP_COMMON_H__

#if defined (HOST_STDA_CM_INTERWORKING)
#if defined (HOST_STDA_APP_LIB)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

#ifdef HAVE_STDC_H
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#endif

/*
******************************************************************************
*	DEFINITION
******************************************************************************
*/

#define	DWALIGN
#define	WDALIGN

#define XDWALIGN		__attribute__ ((aligned(8)))
#define XWALIGN			__attribute__ ((aligned(4)))

#define PACKED
#define XTENSA_PACKED	__attribute__ ((packed))

#if defined(FEATURE_SF_CODE_ENABLE)
#define FLASH_SECTION_FN __attribute__ ((section(".srom.text")))
#else
#define FLASH_SECTION_FN
#endif

#define PACK_STRUCT_BEGIN  PACKED
#define PACK_STRUCT_STRUCT XTENSA_PACKED
#define PACK_STRUCT_END
#define PACK_STRUCT_FIELD(x) x

////////////////////////////////////////////////////////////////////////

#define OS_FLAG_WAIT_CLR_ALL         0u    /* Wait for ALL    the bits specified to be CLR (i.e. 0)   */
#define OS_FLAG_WAIT_CLR_AND         0u

#define OS_FLAG_WAIT_CLR_ANY         1u    /* Wait for ANY of the bits specified to be CLR (i.e. 0)   */
#define OS_FLAG_WAIT_CLR_OR          1u

#define OS_FLAG_WAIT_SET_ALL         2u    /* Wait for ALL    the bits specified to be SET (i.e. 1)   */
#define OS_FLAG_WAIT_SET_AND         2u

#define OS_FLAG_WAIT_SET_ANY         3u    /* Wait for ANY of the bits specified to be SET (i.e. 1)   */
#define OS_FLAG_WAIT_SET_OR          3u

#define OS_FLAG_CONSUME           0x80u    /* Consume the flags if condition(s) satisfied             */

#define OS_FLAG_CLR                  0u
#define OS_FLAG_SET                  1u

////////////////////////////////////////////////////////////////////////

#define EVENT_MASK_PRIMITIVE 	0x00000001
#define EVENT_MASK_TIMER		0x00000002
////////////////////////////////////////////////////////////////////////

#define WORD_MASK_16BITS_MSB	0xFFFF0000
#define WORD_MASK_16BITS_LSB	0x0000FFFF

#define WORD_MASK_MSB_1_OCTET	0xFF000000
#define WORD_MASK_MSB_2_OCTET	0x00FF0000
#define WORD_MASK_MSB_3_OCTET	0x0000FF00
#define WORD_MASK_MSB_4_OCTET	0x000000FF

#define SHORT_MASK_MSB			0xFF00
#define SHORT_MASK_LSB			0x00FF

#define CHAR_MASK_MSB			0xF0
#define CHAR_MASK_LSB			0x0F

////////////////////////////////////////////////////////////////////////

/*
******************************************************************************
*	MACRO
******************************************************************************
*/

////////////////////////////////////////////////////////////////////////
#define offset_of(s,m)      ((UINT32)&(((s *)0)->m))
#define container_of(ptr, type, member) ((type *)((char *)(ptr)-(unsigned long)(&((type *)0)->member)))

#define UPPERCASE(c)        (((c) >= 'a' && (c) <= 'z') ? ((c) - 0x20) : (c))
#define ARRAY_SIZE(x)       (sizeof(x) / sizeof((x)[0]))

////////////////////////////////////////////////////////////////////////
#if !defined (FEATURE_MINI_SHELL)
#define FEATURE_USE_DM_SHELL_HELP_STRING
#endif

#ifdef FEATURE_USE_DM_SHELL_HELP_STRING
#define _H(a)   (a)
#else
#define _H(a)   ("")
#endif

/*
******************************************************************************
*	DATA TYPE
******************************************************************************
*/

////////////////////////////////////////////////////////////////////////

typedef void *PVOID;

typedef unsigned int        BOOL;
typedef unsigned int        bool;

typedef signed char         INT8;
typedef short               INT16;
typedef int                 INT32;
typedef int long long       INT64;

typedef unsigned char       UINT8;
typedef unsigned short      UINT16;
typedef unsigned int        UINT32;
typedef unsigned long long  UINT64;

typedef void				VOID;
typedef unsigned char       CHAR;
typedef unsigned char		BYTE;

typedef unsigned int        size_t;

typedef signed char         int8_t;
typedef short               int16_t;
typedef int                 int32_t;
typedef int long long       int64_t;

typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
typedef unsigned long long  uint64_t;

typedef UINT8    u8_t;
typedef INT8     s8_t;
typedef UINT16   u16_t;
typedef INT16    s16_t;
typedef UINT32   u32_t;
typedef INT32    s32_t;


#if	defined(TNKERNEL)
typedef unsigned int	    BOOLEAN;
typedef unsigned char	    INT8U;                    /* Unsigned  8 bit quantity                           */
typedef signed   char	    INT8S;                    /* Signed    8 bit quantity                           */
typedef unsigned short	    INT16U;                   /* Unsigned 16 bit quantity                           */
typedef signed   short	    INT16S;                   /* Signed   16 bit quantity                           */
typedef unsigned int	    INT32U;                   /* Unsigned 32 bit quantity                           */
typedef signed   int	    INT32S;                   /* Signed   32 bit quantity                           */
typedef float           	FP32;                     /* Single precision floating point                    */
typedef double         	    FP64;                     /* Double precision floating point                    */

typedef unsigned int   OS_STK;                        /* Each stack entry is 16-bit wide                    */
typedef unsigned int   OS_CPU_SR;                     /* Define size of CPU status register (PS = 32 bits)  */
#endif  // TNKERNEL

typedef	UINT32	OS_FLAGS;

#define TASK_NAME_MAX_SIZE  7


////////////////////////////////////////////////////////////////////////
typedef struct _LIST_ENTRY
{
	struct _LIST_ENTRY * Prev;
	struct _LIST_ENTRY * Next;
} LIST_ENTRY, *PLIST_ENTRY;

typedef struct _LIST_TAG
{
	PLIST_ENTRY Head;
	PLIST_ENTRY Tail;
} T_LIST;

typedef struct _MAC_EVENT_TAG
{
	LIST_ENTRY	link;

	UINT32		from;   // Source Task ID
	UINT32		to;     // Destination Task ID
	UINT32      net_idx;// Network ID
	UINT32		code;   // Command ID to be used to primitive
	UINT32		len;    // Parameter Length
	UINT8 *		buf;    // Parameter
} T_MAC_EVENT;

////////////////////////////////////////////////////////////////////////
#define USE_EVENTS              1
#define USE_SEM                 1
#define USE_QUEUE               1
//#define USE_MUTEXES             1
#define OS_TMR_CFG_NAME_SIZE    16
#define	OS_FLAG_GRP				TN_EVENT
#define OS_EVENT                TN_EVENT

typedef struct _CDLL_QUEUE
{
   struct _CDLL_QUEUE * prev;
   struct _CDLL_QUEUE * next;
}CDLL_QUEUE;

typedef struct _TN_TCB
{
   unsigned int * task_stk;   //-- Pointer to task's top of stack
   CDLL_QUEUE task_queue;     //-- Queue is used to include task in ready/wait lists
   CDLL_QUEUE timer_queue;    //-- Queue is used to include task in timer(timeout,etc.) list
   CDLL_QUEUE * pwait_queue;  //-- Ptr to object's(semaphor,event,etc.) wait list,
                                      // that task has been included for waiting (ver 2.x)
   CDLL_QUEUE create_queue;   //-- Queue is used to include task in create list only

#ifdef USE_MUTEXES
   CDLL_QUEUE mutex_queue;    //-- List of all mutexes that tack locked  (ver 2.x)
#endif

   unsigned int * stk_start;  //-- Base address of task's stack space
   int   stk_size;            //-- Task's stack size (in sizeof(void*),not bytes)
   void * task_func_addr;     //-- filled on creation  (ver 2.x)
   void * task_func_param;    //-- filled on creation  (ver 2.x)

   int  base_priority;        //-- Task base priority  (ver 2.x)
   int  priority;             //-- Task current priority
   int  id_task;              //-- ID for verification(is it a task or another object?)
                                      // All tasks have the same id_task magic number (ver 2.x)

   int  task_state;           //-- Task state
   int  task_wait_reason;     //-- Reason for waiting
   int  task_wait_rc;         //-- Waiting return code(reason why waiting  finished)
   unsigned long tick_count;  //-- Remaining time until timeout
   int  tslice_count;         //-- Time slice counter

#ifdef  USE_EVENTS
   int  ewait_pattern;        //-- Event wait pattern
   int  ewait_mode;           //-- Event wait mode:  _AND or _OR
#endif

   void * data_elem;          //-- Store data queue entry,if data queue is full

   int  activate_count;       //-- Activation request count - for statistic
   int  wakeup_count;         //-- Wakeup request count - for statistic
   int  suspend_count;        //-- Suspension count - for statistic

   char	task_name[8];

#ifdef	OS_PROFILER
	unsigned int	os_profile_pretime;
	unsigned int	os_profile_sumtime;
	unsigned int	os_profile_sumtime_save;
#endif   

    // Other implementation specific fields may be added below
    
}TN_TCB;

//----- Semaphore -----

typedef struct _TN_SEM
{
   CDLL_QUEUE  wait_queue;
   int count;
   int max_count;
   int id_sem;     //-- ID for verification(is it a semaphore or another object?)
                         // All semaphores have the same id_sem magic number (ver 2.x)
   int valid;
}TN_SEM;

//----- Eventflag -----

typedef struct _TN_EVENT
{
   CDLL_QUEUE wait_queue;
   int attr;               //-- Eventflag attribute
   unsigned int pattern;   //-- Initial value of the eventflag bit pattern
   int id_event;           //-- ID for verification(is it a event or another object?)
                                // All events have the same id_event magic number (ver 2.x)
}TN_EVENT;

//----- Data queue -----

typedef struct _TN_DQUE
{
   CDLL_QUEUE  wait_send_list;
   CDLL_QUEUE  wait_receive_list;

   void ** data_fifo;   //-- Array of void* to store data queue entries
   int  num_entries;    //-- Capacity of data_fifo(num entries)
   int  tail_cnt;       //-- Counter to processing data queue's Array of void*
   int  header_cnt;     //-- Counter to processing data queue's Array of void*
   int  id_dque;        //-- ID for verification(is it a data queue or another object?)
                               // All data queues have the same id_dque magic number (ver 2.x)
   int  valid;
}TN_DQUE;

//----- Mutex ------------

typedef struct _TN_MUTEX
{
   CDLL_QUEUE wait_queue;        //-- List of tasks that wait a mutex
   CDLL_QUEUE mutex_queue;       //-- To include in task's locked mutexes list (if any)
   CDLL_QUEUE lock_mutex_queue;  //-- To include in system's locked mutexes list
   int attr;                     //-- Mutex creation attr - CEILING or INHERIT

   TN_TCB * holder;              //-- Current mutex owner(task that locked mutex)
   int ceil_priority;            //-- When mutex created with CEILING attr
   int cnt;                      //-- Reserved
   int id_mutex;                 //-- ID for verification(is it a mutex or another object?)
                                       // All mutexes have the same id_mutex magic number (ver 2.x)
}TN_MUTEX;

typedef	void (*OS_TMR_CALLBACK)(void *ptmr, UINT32 parg);

typedef	struct	os_tmr
{
	OS_TMR_CALLBACK			OSTmrCallBack;
	UINT32					OSTmrCallBackArg;
	void					*OSTmrNext;
	void					*OSTmrPrev;
	UINT32					OSTmrDly;
	UINT32					OSTmrPeriod;
	UINT8					OSTmrName[OS_TMR_CFG_NAME_SIZE];
	UINT8					OSTmrState;
	UINT8					option;
	UINT8					runflag;
	UINT8					reserved;
} OS_TMR;

typedef	void (*SW_TIMER_CALLBACK)(void *pTmrCntx, UINT32 timerId);

typedef struct
{
    SW_TIMER_CALLBACK timerCb;
    UINT32  interval;
    UINT32  expireCnt;    
    UINT8   bEnable;
    UINT8   bPeriod;
    UINT8   bTrigger;
} SW_TIMER;

typedef struct
{
    SW_TIMER    *pList;
    OS_TMR      *pOsTimer;
    OS_FLAG_GRP *pRcvTaskFlag;
    UINT32      baseInterval;    
    UINT8       noOfTimer;    
    UINT8       bOsTimerStarted;
    UINT8       noOfActTimer;
} SW_TIMER_CNTX;

typedef struct
{
    UINT32      timerID;
    UINT8       name[32];
    UINT32      interval;
    UINT8       bPeriod;
    void *      callback;
    UINT8       bActive;
} APP_TIMER_HANDLER;

////////////////////////////////////////////////////////////////////////
typedef enum
{
    SHELL_NULL,
    SHELL_INVALID_CMD,
    SHELL_INVALID_PARAM,
    SHELL_OK
} SHELL_ERR;

typedef struct _SHELL_CNTX
{
    UINT32  id;
    char    *cmdString;
    char    *helpString;
    SHELL_ERR (*action)(UINT32 id, char *param, UINT32 size);
    const struct _SHELL_CNTX *subCntx;
} SHELL_CNTX;

////////////////////////////////////////////////////////////////////////
enum
{
	GPIO_0	=0, /* SDIO RESET */
	GPIO_1,
	GPIO_2,
	GPIO_3,
	GPIO_4,
	GPIO_5,
	GPIO_6,
	GPIO_7,
	GPIO_8,     /* UART 0 */
	GPIO_9,     /* UART 0 */
	GPIO_10,    /* UART 1 */
	GPIO_11,    /* UART 1 */
	GPIO_12,    /* UART 2 */
	GPIO_13,    /* UART 2 */
	GPIO_14,
	GPIO_15,
#if defined (CHIP_WF6000)
    GPIO_16,    /* SF_SIO2 */
    GPIO_17,    /* SF_SIO3 */
    GPIO_18,
    GPIO_19,
    GPIO_20,    /* Out only */
    GPIO_21,
    GPIO_22,
    GPIO_23,
    GPIO_24,
    GPIO_25,
    GPIO_26,    /* RSTN pad muxing, So should not use */
#endif
	GPIO_MAX
};

////////////////////////////////////////////////////////////////////////
#define fMACBRK       (1 << 0)
#define fMACPEN       (1 << 1)
#define fMACEPS       (1 << 2)
#define fMACSTP2      (1 << 3)
#define fMACFEN       (1 << 4)
#define fMACWLEN(a)   ((a) << 5)
#define fMACSPS       (1 << 7)

typedef enum
{
    UART_WORD_LEN_5BITS,            // 00b
    UART_WORD_LEN_6BITS,            // 01b
    UART_WORD_LEN_7BITS,            // 10b
    UART_WORD_LEN_8BITS             // 11b
}
UART_WORD_LEN;

#define fMACUARTEN    (1<<0)
#define fMACLBE       (1<<7)
#define fMACTXE       (1<<8)
#define fMACRXE       (1<<9)
#define fMACRTS       (1<<11)
#define fMACRTSEn     (1<<14)
#define fMACCTSEn     (1<<15)

typedef enum
{
    UART0,
    UART1,
    UART2,
    UART_NO,
} UART_PORT;
#if 0
typedef struct
{
    UINT32  wr_ptr;
    UINT32  rd_ptr;
} UART_IDLE;

typedef struct
{
    UART_PORT   port;
    UINT32      baudRate;
    UINT32      baseAddress;
    UINT32      isTxProcess;
    UINT32      rxPtrHeader;
    UINT32      rxPtrTail;
    UINT32      txPtrHeader;
    UINT32      txPtrTail;
    UINT32      isRxOverrun;
    UINT32      isTxOverrun;
    UINT32      INTR_REG;
    UINT32      INTR_MASK;
    UINT32      dmaTxPreTotalSize;
    UINT32      dmaRxPreTotalSize;    
    UINT32      rxBuffSize;
    UINT32      txBuffSize;
    UART_IDLE   idle_uart;
    
    void        (*rxEventHandlerForTask)(void);      

    UINT8       *rxBuffer;
    UINT8       *txBuffer;
} UART_CNTX;
#endif
////////////////////////////////////////////////////////////////////////

/* Definitions for error constants. */

#define ERR_OK           0    /* No error, everything OK. */
#define ERR_MEM         -1    /* Out of memory error.     */
#define ERR_BUF         -2    /* Buffer error.            */
#define ERR_TIMEOUT     -3    /* Timeout.                 */
#define ERR_RTE         -4    /* Routing problem.         */
#define ERR_INPROGRESS  -5    /* Operation in progress    */
#define ERR_VAL         -6    /* Illegal value.           */
#define ERR_WOULDBLOCK  -7    /* Operation would block.   */
#define ERR_USE         -8    /* Address in use.          */
#define ERR_ISCONN      -9    /* Already connected.       */

#define ERR_IS_FATAL(e) ((e) < ERR_ISCONN)

#define ERR_ABRT        -10   /* Connection aborted.      */
#define ERR_RST         -11   /* Connection reset.        */
#define ERR_CLSD        -12   /* Connection closed.       */
#define ERR_CONN        -13   /* Not connected.           */

#define ERR_ARG         -14   /* Illegal argument.        */

#define ERR_IF          -15   /* Low-level netif error    */

#define NUM_OF_SOCKETS   6    /* Don't Change */

typedef enum MANAGEMENT_FRAME_STAUS_CODE_TAG
{
    STATUS_SUCCESSFUL = 0,      /* WLAN_STATUS_SUCCESS */
    STATUS_CODE_01,             /* WLAN_STATUS_UNSPECIFIED_FAILURE */
    STATUS_CODE_02,             /* WLAN_STATUS_TDLS_WAKEUP_ALTERNATE */
    STATUS_CODE_03,             /* WLAN_STATUS_TDLS_WAKEUP_SCHEDULE_REJECT */
    STATUS_CODE_05 = 5,         /* WLAN_STATUS_SECURITY_DISABLED */
    STATUS_CODE_06,             /* WLAN_STATUS_UNACCEPTABLE_LIFETIME */
    STATUS_CODE_07,             /* WLAN_STATUS_NOT_IN_SAME_BSS */
    STATUS_CODE_10 = 10,        /* WLAN_STATUS_CAPS_UNSUPPORTED */
    STATUS_CODE_11,             /* WLAN_STATUS_REASSOC_NO_ASSOC */
    STATUS_CODE_12,             /* WLAN_STATUS_ASSOC_DENIED_UNSPEC */
    STATUS_CODE_13,             /* WLAN_STATUS_NOT_SUPPORTED_AUTH_ALG */
    STATUS_CODE_14,             /* WLAN_STATUS_UNKNOWN_AUTH_TRANSACTION */
    STATUS_CODE_15,             /* WLAN_STATUS_CHALLENGE_FAIL */
    STATUS_CODE_16,             /* WLAN_STATUS_AUTH_TIMEOUT */
    STATUS_CODE_17,             /* WLAN_STATUS_AP_UNABLE_TO_HANDLE_NEW_STA */
    STATUS_CODE_18,             /* WLAN_STATUS_ASSOC_DENIED_RATES */
    STATUS_CODE_19,             /* WLAN_STATUS_ASSOC_DENIED_NOSHORT */
    STATUS_CODE_20 = 20,        /* WLAN_STATUS_ASSOC_DENIED_NOPBCC */
    STATUS_CODE_21,             /* WLAN_STATUS_ASSOC_DENIED_NOAGILITY */
    STATUS_CODE_22,             /* WLAN_STATUS_SPEC_MGMT_REQUIRED */
    STATUS_CODE_23,             /* WLAN_STATUS_PWR_CAPABILITY_NOT_VALID */
    STATUS_CODE_24,             /* WLAN_STATUS_SUPPORTED_CHANNEL_NOT_VALID */
    STATUS_CODE_25,             /* WLAN_STATUS_ASSOC_DENIED_NO_SHORT_SLOT_TIME */
    STATUS_CODE_26,             /* WLAN_STATUS_ASSOC_DENIED_NO_DSSS_OFDM */
    STATUS_CODE_27,             /* WLAN_STATUS_ASSOC_DENIED_NO_HT */
    STATUS_CODE_28,             /* WLAN_STATUS_R0KH_UNREACHABLE */
    STATUS_CODE_29,             /* WLAN_STATUS_ASSOC_DENIED_NO_PCO */
    STATUS_CODE_30 = 30,        /* WLAN_STATUS_ASSOC_REJECTED_TEMPORARILY */
    STATUS_CODE_31,             /* WLAN_STATUS_ROBUST_MGMT_FRAME_POLICY_VIOLATION */
    STATUS_CODE_32,             /* WLAN_STATUS_UNSPECIFIED_QOS_FAILURE */
    STATUS_CODE_33,
    STATUS_CODE_34,
    STATUS_CODE_35,
    STATUS_CODE_36,
    STATUS_CODE_REFUSED,        /* WLAN_STATUS_REQUEST_DECLINED */
    STATUS_CODE_38,             /* WLAN_STATUS_INVALID_PARAMETERS */
    STATUS_CODE_39,
    STATUS_CODE_40 = 40,        /* WLAN_STATUS_INVALID_IE */
    STATUS_CODE_41,             /* WLAN_STATUS_GROUP_CIPHER_NOT_VALID */
    STATUS_CODE_42,             /* WLAN_STATUS_PAIRWISE_CIPHER_NOT_VALID */
    STATUS_CODE_43,             /* WLAN_STATUS_AKMP_NOT_VALID */
    STATUS_CODE_44,             /* WLAN_STATUS_UNSUPPORTED_RSN_IE_VERSION */
    STATUS_CODE_45,             /* WLAN_STATUS_INVALID_RSN_IE_CAPAB */
    STATUS_CODE_46,             /* WLAN_STATUS_CIPHER_REJECTED_PER_POLICY */
    STATUS_CODE_47,             /* WLAN_STATUS_TS_NOT_CREATED */
    STATUS_CODE_NOT_ALLOWED,    /* WLAN_STATUS_DIRECT_LINK_NOT_ALLOWED */
    STATUS_CODE_NOT_PRESENT,    /* WLAN_STATUS_DEST_STA_NOT_PRESENT */
    STATUS_CODE_NOT_QOS_STA,    /* WLAN_STATUS_DEST_STA_NOT_QOS_STA */
    STATUS_CODE_51,             /* WLAN_STATUS_ASSOC_DENIED_LISTEN_INT_TOO_LARGE */
    STATUS_CODE_52,             /* WLAN_STATUS_INVALID_FT_ACTION_FRAME_COUNT */
    STATUS_CODE_53,             /* WLAN_STATUS_INVALID_PMKID */
    STATUS_CODE_54,             /* WLAN_STATUS_INVALID_MDIE */
    STATUS_CODE_55,             /* WLAN_STATUS_INVALID_FTIE */
    STATUS_CODE_59 = 59,        /* WLAN_STATUS_GAS_ADV_PROTO_NOT_SUPPORTED */
    STATUS_CODE_60,             /* WLAN_STATUS_NO_OUTSTANDING_GAS_REQ */
    STATUS_CODE_61,             /* WLAN_STATUS_GAS_RESP_NOT_RECEIVED */  
    STATUS_CODE_62,             /* WLAN_STATUS_STA_TIMED_OUT_WAITING_FOR_GAS_RESP */ 
    STATUS_CODE_63,             /* WLAN_STATUS_GAS_RESP_LARGER_THAN_LIMIT */  
    STATUS_CODE_64,             /* WLAN_STATUS_REQ_REFUSED_HOME */   
    STATUS_CODE_65,             /* WLAN_STATUS_ADV_SRV_UNREACHABLE */  
    STATUS_CODE_67,             /* WLAN_STATUS_REQ_REFUSED_SSPN */     
    STATUS_CODE_68,             /* WLAN_STATUS_REQ_REFUSED_UNAUTH_ACCESS */   
    STATUS_CODE_72,             /* WLAN_STATUS_INVALID_RSNIE */  
    STATUS_CODE_79,             /* WLAN_STATUS_TRANSMISSION_FAILURE */         
    STATUS_CODE_MAX
} T_MANAGEMENT_FRAME_STATUS_CODE;

typedef enum MANAGEMENT_FRAME_REACON_CODE_TAG
{
    REASON_CODE_00 = 0,
    REASON_CODE_01,             /* WLAN_REASON_UNSPECIFIED */
    REASON_CODE_02,             /* WLAN_REASON_PREV_AUTH_NOT_VALID */
    REASON_CODE_03,             /* WLAN_REASON_DEAUTH_LEAVING */
    REASON_CODE_04,             /* WLAN_REASON_DISASSOC_DUE_TO_INACTIVITY */
    REASON_CODE_05,             /* WLAN_REASON_DISASSOC_AP_BUSY */
    REASON_CODE_06,             /* WLAN_REASON_CLASS2_FRAME_FROM_NONAUTH_STA */
    REASON_CODE_07,             /* WLAN_REASON_CLASS3_FRAME_FROM_NONASSOC_STA */
    REASON_CODE_08,             /* WLAN_REASON_DISASSOC_STA_HAS_LEFT */
    REASON_CODE_09,             /* WLAN_REASON_STA_REQ_ASSOC_WITHOUT_AUTH */
    REASON_CODE_10 = 10,        /* WLAN_REASON_PWR_CAPABILITY_NOT_VALID */
    REASON_CODE_11,             /* WLAN_REASON_SUPPORTED_CHANNEL_NOT_VALID */
    REASON_CODE_12,
    REASON_CODE_13,             /* WLAN_REASON_INVALID_IE */
    REASON_CODE_14,             /* WLAN_REASON_MICHAEL_MIC_FAILURE */
    REASON_CODE_15,             /* WLAN_REASON_4WAY_HANDSHAKE_TIMEOUT */
    REASON_CODE_16,             /* WLAN_REASON_GROUP_KEY_UPDATE_TIMEOUT */
    REASON_CODE_17,             /* WLAN_REASON_IE_IN_4WAY_DIFFERS */
    REASON_CODE_18,             /* WLAN_REASON_GROUP_CIPHER_NOT_VALID */
    REASON_CODE_19,             /* WLAN_REASON_PAIRWISE_CIPHER_NOT_VALID */
    REASON_CODE_20,             /* WLAN_REASON_AKMP_NOT_VALID */
    REASON_CODE_21,             /* WLAN_REASON_UNSUPPORTED_RSN_IE_VERSION */
    REASON_CODE_22,             /* WLAN_REASON_INVALID_RSN_IE_CAPAB */
    REASON_CODE_23,             /* WLAN_REASON_IEEE_802_1X_AUTH_FAILED */
    REASON_CODE_24,             /* WLAN_REASON_CIPHER_SUITE_REJECTED */
    REASON_CODE_25,             /* WLAN_REASON_TDLS_TEARDOWN_UNREACHABLE */
    REASON_CODE_26,             /* WLAN_REASON_TDLS_TEARDOWN_UNSPECIFIED */    
    REASON_CODE_32 = 32,        
    REASON_CODE_33,
    REASON_CODE_34,             /* WLAN_REASON_DISASSOC_LOW_ACK */
    REASON_CODE_35,
    REASON_CODE_36,
    REASON_CODE_37,             /* WLAN_REASON_END_TS_END_BA_END_DLS */
    REASON_CODE_38,
    REASON_CODE_39,             /* TIMEOUT */
    REASON_CODE_45 = 45,
    REASON_CODE_MAX
} T_MANAGEMENT_FRAME_REASON_CODE;

////////////////////////////////////////////////////////////////////////
// Flash
typedef enum 
{
    FW_NO_ERROR = 0,
    FW_SIGNATURE_INVALID_ERR,
    FW_DRAM_CRC_ERR,
    FW_IRAM_CRC_ERR,
    FW_SF_CODE_CRC_ERR,
    FW_DRAM_SIZE_ERR,
    FW_IRAM_SIZE_ERR,
    FW_SF_CODE_SIZE_ERR,
    FW_WEBUI_UPLOAD_ABORT,
    FW_OTA_SERVER_ERR,
    FW_REF_CLOCK_ERR,
    
}FW_VALIDITY_RESULT;

#define SF_BANK_ID_1    (1)
#define SF_BANK_ID_2    (2)

////////////////////////////////////////////////////////////////////////

//bss_type
#define BSS_TYPE_UNSPEC             0
#define BSS_TYPE_INDEPENDENT        1
#define BSS_TYPE_INFRASTRUCTURE     2
#define BSS_TYPE_AP                 3
#define BSS_TYPE_ANY                10

//bss_sub_type
#define BSS_SUB_TYPE_NONE           0x00
#define BSS_SUB_TYPE_WPS            0x01
#define BSS_SUB_TYPE_P2P            0x02
#define BSS_SUB_TYPE_OTHERS         0x04

////////////////////////////////////////////////////////////////////////
// NV Memory
#define MAX_NV_CM_DATA_LEN          1024
#define MAX_NV_CM_DATA_LEN_0        512
#define MAX_NV_CM_DATA_LEN_1        512

/* NV_ITEM_ANT_TYPE */
#define NV_ANT_CHIP                 0
#define NV_ANT_UFL                  1

////////////////////////////////////////////////////////////////////////
// Firmware Debug Level
#define DBG_LVL_CLEAR   (0)
#define DBG_LVL_ERR     (1)
#define DBG_LVL_WARN    (2)
#define DBG_LVL_TRACE   (3)
#define DBG_LVL_INFO    (4)
#define DBG_LVL_NONE    (5)

////////////////////////////////////////////////////////////////////////
// Power Save
enum 
{
    HW_PS_MODE_NONE,
    HW_PS_MODE_ACTIVE,
    HW_PS_MODE_STOP,
};

enum 
{
    HW_PS_STATUS_AWAKE,
    HW_PS_STATUS_SLEEP,
};

/* dot11PowerManagementMode */
#define POWER_MODE_AUTO                 0
#define	POWER_MODE_ACTIVE				1
#define POWER_MODE_POWERSAVE			2

////////////////////////////////////////////////////////////////////////
// MAC WiFi Config MIB
typedef enum
{
	MIB_AT_CMD_TYPE,
	MIB_DATA_TYPE
} T_MIB_TYPE;

typedef enum WIFI_CFG_TAG
{
    WIFI_CFG_SSID,
    WIFI_CFG_CHANNEL,
    WIFI_CFG_NETWORK_MODE,
    WIFI_CFG_ENCRYPT_PROTOCOL,
    WIFI_CFG_PAIRWISE_CIPHER,
    WIFI_CFG_GROUP_CIPHER,
    WIFI_CFG_WEP_KEY,
    WIFI_CFG_WPA_PSK,
    WIFI_CFG_KEY_IDX,
    WIFI_CFG_ENTR_TYPE,
    WIFI_CFG_ENTR_ID,
    WIFI_CFG_ENTR_PASSWD,
    WIFI_CFG_CACERT_FILE,
    WIFI_CFG_CERT_FILE,
    WIFI_CFG_KEY_FILE,
    WIFI_CFG_SN,
    WIFI_CFG_DEV_CODE,
    WIFI_CFG_DEV_TYPE,
    WIFI_CFG_DEV_NAME,
    WIFI_CFG_MODEL_NAME,
    WIFI_CFG_MANUFACTURE,
    WIFI_CFG_P2P_TYPE,
    WIFI_CFG_P2P_METHOD,
    WIFI_CFG_P2P_PIN,
    WIFI_CFG_MNG_MAX, 

    WIFI_CFG_VERSION = 0x20,
    WIFI_CFG_MAC_ADDR,
    WIFI_CFG_BSSID,
    WIFI_CFG_FREQ,
    WIFI_CFG_BAUD_RATE,
    WIFI_CFG_WIFI_CONN_STATUS,
    WIFI_CFG_BAS_MNG_MAX,

    WIFI_CFG_RTS_THRESHOLD = 0x40,
    WIFI_CFG_CTS_THRESHOLD,
    WIFI_CFG_FRAG_THRESHOLD,
    WIFI_CFG_BEACON_INTERVAL,
    WIFI_CFG_RF_MNG_MAX,

    WIFI_CFG_IP_ADDR = 0x60,
    WIFI_CFG_SUBNET_MASK,
    WIFI_CFG_GATEWAY_ADDR,
    WIFI_CFG_DNS,
    WIFI_CFG_IP_TYPE,
    WIFI_CFG_DHCP_LEASE_IP,
    WIFI_CFG_SVC_PORT,
    WIFI_CFG_UDAP_PORT,
    WIFI_CFG_RT_NET_STATUS,
    WIFI_CFG_SOCK_IP,
    WIFI_CFG_SOCK_PORT,
    WIFI_CFG_NET_MNG_MAX,

    WIFI_CFG_RSSI = 0x70,
    WIFI_CFG_ROAM_RSSI,
    WIFI_CFG_STAT_MNG_MAX,

    WIFI_CFG_DATA_MAX,

    WIFI_CFG_SPECIFIC = 0xd0,
    WIFI_CFG_MAX
} T_WIFI_CFG;

////////////////////////////////////////////////////////////////////////
// WPA Security
typedef enum 
{
    WPA_AUTH_ENC_TYPE_NONE = 0,
    WPA_AUTH_ENC_TYPE_WEP,
    WPA_AUTH_ENC_TYPE_WPA_PSK,
    WPA_AUTH_ENC_TYPE_WPA,
    WPA_AUTH_ENC_TYPE_WPA2_PSK,
    WPA_AUTH_ENC_TYPE_WPA2
} WPA_AUTH_ENC_TYPE;

typedef enum 
{
    WPA_EAP_TYPE_NONE = 0,
    WPA_EAP_TYPE_TTLS,
    WPA_EAP_TYPE_TLS,    
    WPA_EAP_TYPE_PEAP,    
    WPA_EAP_TYPE_LEAP,
    WPA_EAP_TYPE_FAST
} WPA_EAP_TYPE;

typedef enum
{
    WIFISUPP_NETWORK_MODE_INFRASTRUCTURE,   //infrastructure
    WIFISUPP_NETWORK_MODE_ADHOC,            //ad-hoc
    WIFISUPP_NETWORK_MODE_SOFTAP,           //softap
    WIFISUPP_NETWORK_MODE_P2P,              //p2p
    WIFISUPP_NETWORK_MODE_MAX
} WIFISUPP_NETWORK_MODE_E;

typedef enum
{
    WIFISUPP_ENCRYP_PROTOCOL_OPENSYS,   //open system
    WIFISUPP_ENCRYP_PROTOCOL_WEP,       //WEP
    WIFISUPP_ENCRYP_PROTOCOL_WPA,       //WPA
    WIFISUPP_ENCRYP_PROTOCOL_WPA2,      //WPA2
    WIFISUPP_ENCRYP_PROTOCOL_WAPI,      //WAPI
    WIFISUPP_ENCRYP_PROTOCOL_WPA_ENTR,  //WPA_ENTERPRISE
    WIFISUPP_ENCRYP_PROTOCOL_WPA2_ENTR, //WPA2_ENTERPRISE    
    WIFISUPP_ENCRYP_PROTOCOL_MAX
}WIFISUPP_ENCRYP_PROTOCOL_E;

typedef enum
{
    WIFISUPP_CIPHER_TKIP,       //TKIP
    WIFISUPP_CIPHER_CCMP,       //CCMP
    WIFISUPP_CIPHER_WEP,
    WIFISUPP_CIPHER_SMS4,       //WAPI SMS-4����
    WIFISUPP_CIPHER_NONE,
    WIFISUPP_CIPHER_IGTK,
    WIFISUPP_CIPHER_WAPI,
    WIFISUPP_CIPHER_BIP,
    WIFISUPP_CIPHER_MAX
} WIFISUPP_CIPHER_E;

typedef enum
{
    WIFISUPP_ENCRYP_ENT_PROTOCOL_WPA,
    WIFISUPP_ENCRYP_ENT_PROTOCOL_WPA2,
    
    WIFISUPP_ENCRYP_ENT_PROTOCOL_MAX
} WIFISUPP_ENCRYP_ENT_PROTOCOL_E;

typedef enum
{
    WIFISUPP_ENCRYP_ENT_TYPE_NONE,
    WIFISUPP_ENCRYP_ENT_TYPE_TLS,
    WIFISUPP_ENCRYP_ENT_TYPE_TTLS,
    WIFISUPP_ENCRYP_ENT_TYPE_PEAP,
    WIFISUPP_ENCRYP_ENT_TYPE_LEAP,
    WIFISUPP_ENCRYP_ENT_TYPE_FAST,
    
    WIFISUPP_ENCRYP_ENT_TYPE_MAX
} WIFISUPP_ENCRYP_ENT_TYPE_E;

////////////////////////////////////////////////////////////////////////
// Security
//auth_type -
#define MIB_AUTH_OPEN_SYSTEM	        0
#define MIB_AUTH_SHARED_KEY		        1
#define MIB_AUTH_FT                     2
#define MIB_AUTH_NETWORK_EAP            3
#define MIB_AUTH_AUTO_SWITCH            4

//auth_enc_type
typedef enum 
{
    AUTH_ENC_TYPE_NONE = 0,
    AUTH_ENC_TYPE_WEP,
    AUTH_ENC_TYPE_WPA_PSK,
    AUTH_ENC_TYPE_WPA,
    AUTH_ENC_TYPE_WPA2_PSK,
    AUTH_ENC_TYPE_WPA2
} AUTH_ENC_TYPE;

//pairwise_cipher
typedef enum 
{
    PAIRWISE_CIPHER_NONE = 0,
    PAIRWISE_CIPHER_TKIP,
    PAIRWISE_CIPHER_CCMP,
    PAIRWISE_CIPHER_BIP,
    PAIRWISE_CIPHER_GCMP,
} AUTH_PAIRWISE_CIPHER;

//group_cipher
typedef enum 
{
    GROUP_CIPHER_NONE = 0,
    GROUP_CIPHER_TKIP,
    GROUP_CIPHER_CCMP,
    GROUP_CIPHER_BIP,
    GROUP_CIPHER_GCMP,
} AUTH_GROUP_CIPHER;

////////////////////////////////////////////////////////////////////////
// File System
#if defined (FEATURE_FILE_SYSTEM_FATFS)
/* File function return code (FRESULT) */
typedef enum {
	FR_OK = 0,				/* (0) Succeeded */
	FR_DISK_ERR,			/* (1) A hard error occurred in the low level disk I/O layer */
	FR_INT_ERR,				/* (2) Assertion failed */
	FR_NOT_READY,			/* (3) The physical drive cannot work */
	FR_NO_FILE,				/* (4) Could not find the file */
	FR_NO_PATH,				/* (5) Could not find the path */
	FR_INVALID_NAME,		/* (6) The path name format is invalid */
	FR_DENIED,				/* (7) Access denied due to prohibited access or directory full */
	FR_EXIST,				/* (8) Access denied due to prohibited access */
	FR_INVALID_OBJECT,		/* (9) The file/directory object is invalid */
	FR_WRITE_PROTECTED,		/* (10) The physical drive is write protected */
	FR_INVALID_DRIVE,		/* (11) The logical drive number is invalid */
	FR_NOT_ENABLED,			/* (12) The volume has no work area */
	FR_NO_FILESYSTEM,		/* (13) There is no valid FAT volume */
	FR_MKFS_ABORTED,		/* (14) The f_mkfs() aborted due to any parameter error */
	FR_TIMEOUT,				/* (15) Could not get a grant to access the volume within defined period */
	FR_LOCKED,				/* (16) The operation is rejected according to the file sharing policy */
	FR_NOT_ENOUGH_CORE,		/* (17) LFN working buffer could not be allocated */
	FR_TOO_MANY_OPEN_FILES,	/* (18) Number of open files > _FS_SHARE */
	FR_INVALID_PARAMETER	/* (19) Given parameter is invalid */
} FRESULT;

typedef enum {
	FR_WRITE_OK = 0,		/* (0) Succeeded for file write operation */
	FR_NOT_ENOUGH_SPACE = 0x100, /* Disk has not enough space */
	FR_MEM_ALLOC_FAIL,		/* MEM Alloc fail */
} FWRITE_RESULT;

typedef unsigned short	    WORD;
typedef unsigned long	    DWORD;
typedef char TCHAR;

typedef struct {
	DWORD	fsize;			/* File size */
	WORD	fdate;			/* Last modified date */
	WORD	ftime;			/* Last modified time */
	BYTE	fattrib;		/* Attribute */
	TCHAR	fname[13];		/* Short file name (8.3 format) */
#if _USE_LFN
	TCHAR*	lfname;			/* Pointer to the LFN buffer */
	UINT 	lfsize;			/* Size of LFN buffer in TCHAR */
#endif
} FILINFO;

/* File attribute bits for directory entry */
#define	AM_RDO	0x01	/* Read only */
#define	AM_HID	0x02	/* Hidden */
#define	AM_SYS	0x04	/* System */
#define	AM_VOL	0x08	/* Volume label */
#define AM_LFN	0x0F	/* LFN entry */
#define AM_DIR	0x10	/* Directory */
#define AM_ARC	0x20	/* Archive */
#define AM_MASK	0x3F	/* Mask of defined bits */

#elif defined (FEATURE_FILE_SYSTEM_PFF)
/* File function return code (FRESULT) */
typedef enum {
	FR_OK = 0,			/* 0 */
	FR_DISK_ERR,		/* 1 */
	FR_NOT_READY,		/* 2 */
	FR_NO_FILE,			/* 3 */
	FR_NOT_OPENED,		/* 4 */
	FR_NOT_ENABLED,		/* 5 */
	FR_NO_FILESYSTEM	/* 6 */
} FRESULT;
#endif

////////////////////////////////////////////////////////////////////////
// P2P
#if defined (CONFIG_P2P)
typedef enum 
{
    P2P_CONF_BSS_SUB_TYPE = 0,
    P2P_CONF_TYPE,
    P2P_CONF_METHOD
} T_P2P_CONFIG;

typedef enum /* P2P_CONF_TYPE */
{
    P2P_TYPE_PASSIVE = 0,
    P2P_TYPE_ACTIVE
} T_P2P_CONF_TYPE;

typedef enum /* P2P_CONF_METHOD */
{
    P2P_METHOD_PBC = 0,
    P2P_METHOD_PIN,
    P2P_METHOD_BOTH
} T_P2P_CONF_METHOD;

typedef enum /* P2P_NOTIFY_METHOD */
{
    P2P_NOTIFY_PBC = 0,
    P2P_NOTIFY_DISPLAY,
    P2P_NOTIFY_KEYPAD
} T_P2P_NOTIFY_METHOD;
#endif /* CONFIG_P2P */

////////////////////////////////////////////////////////////////////////
// HTTPC
#if defined (FEATURE_HTTPC_SUPP)
typedef enum
{
    HTTPC_RESULT_OK = 0,             
    HTTPC_RESULT_ERR_UNKNOWN,        /** Unknown error */
    HTTPC_RESULT_ERR_CONNECT,        /** Connection to server failed */
    HTTPC_RESULT_ERR_HOSTNAME,       /** Failed to resolve server hostname */
    HTTPC_RESULT_ERR_CLOSED,         /** Connection unexpectedly closed by remote server */
    HTTPC_RESULT_ERR_TIMEOUT,        /** Connection timed out (server didn't respond in time) */
    HTTPC_RESULT_ERR_SVR_RESP,       /** Server responded with an unknown response code */
    HTTPC_RESULT_ERR_INITIALIZE,     /** initialization error */
    HTTPC_RESULT_ERR_ARGUMENT,
    HTTPC_RESULT_ERR_MEMORY,
    HTTPC_RESULT_SESSION_SUCCESS,    /** Session success */
    HTTPC_RESULT_SESSION_CLOSED,     /** Session closed */
    HTTPC_RESULT_OK_SVR_RESP,
    HTTPC_RESULT_ERR_UPNP_NOT_SUPP,
    
    HTTPC_RESULT_MAX
} HTTPC_RESULT_E;

#elif defined (FEATURE_HTTPC_V2_SUPP)
typedef enum
{
    HTTPC_RESULT_OK = 0,             
    HTTPC_RESULT_ERR_UNKNOWN,        /** Unknown error */
    HTTPC_RESULT_ERR_CONNECT,        /** Connection to server failed */
    HTTPC_RESULT_ERR_HOSTNAME,       /** Failed to resolve server hostname */
    HTTPC_RESULT_ERR_CLOSED,         /** Connection unexpectedly closed by remote server */
    HTTPC_RESULT_ERR_TIMEOUT,        /** Connection timed out (server didn't respond in time) */
    HTTPC_RESULT_ERR_SVR_RESP,       /** Server responded with an unknown response code */
    HTTPC_RESULT_ERR_INITIALIZE,     /** initialization error */
    HTTPC_RESULT_ERR_ARGUMENT,
    HTTPC_RESULT_ERR_MEMORY,
    HTTPC_RESULT_SESSION_SUCCESS,    /** Session success */
    HTTPC_RESULT_SESSION_CLOSED,     /** Session closed */
    HTTPC_RESULT_OK_SVR_RESP,
    HTTPC_RESULT_ERR_UPNP_NOT_SUPP,
    HTTPC_RESULT_ERR_ROOT_CERT_FILE,
    
    HTTPC_RESULT_MAX
} HTTPC_RESULT_E;

#endif /* FEATURE_HTTPC_SUPP */

#if defined (FEATURE_FILE_SYSTEM_FATFS) && (defined (FEATURE_HTTPC_SUPP) || defined (FEATURE_HTTPC_V2_SUPP))
typedef enum
{
    HTTPC_DOWNLOAD_RESULT_OK = 0,
    HTTPC_DOWNLOAD_RESULT_ERR_RESPONSECODE,
    HTTPC_DOWNLOAD_RESULT_ERR_FILEWRITE,
    HTTPC_DOWNLOAD_RESULT_ERR_FILESIZE,
    HTTPC_DOWNLOAD_RESULT_ERR_MEMORY,
    HTTPC_DOWNLOAD_RESULT_ERR_CONNECTION,

    HTTPC_DOWNLOAD_RESULT_MAX
} HTTPC_DOWNLOAD_RESULT_E;
#endif

////////////////////////////////////////////////////////////////////////
// MQTT
#if defined (FEATURE_MQTT_SUPP) || defined (FEATURE_MQTT_PAHO_EMB_SUPP)
typedef struct PACKED
{
#if defined (FETURE_MQTT_MIB_V1)
    UINT8   server_ip[32];
    UINT16  port;
    UINT8   ssl;
    UINT8   user_name[32];
    UINT8   password[32];
    UINT8   pub_topic[64];
    UINT8   sub_topic[64];
    UINT8   pub_qos;
    UINT8   sub_qos;
    UINT8   client_id[20];
    UINT8   persistence;
    UINT8   will_topic[32];
    UINT8   will_msg[32];
    UINT16  keepalive;              // 316 bytes / 320bytes
#elif defined (FEATURE_MQTT_MIB_V2)
    UINT8   server_ip[32];
    UINT16  port;
    UINT8   ssl;
    UINT8   user_name[32];
    UINT8   password[64];
    UINT8   pub_topic[64];
    UINT8   sub_topic[64];
    UINT8   pub_qos;
    UINT8   sub_qos;
    UINT8   client_id[32];
    UINT8   persistence;
    UINT8   will_topic[32];
    UINT8   will_msg[64];
    UINT16  keepalive;
    UINT8   reserved[120];          // 512 bytes
#elif defined (FEATURE_MQTT_MIB_V3)
    UINT8   server_ip[32];
    UINT16  port;
    UINT8   ssl;
    UINT8   user_name[48];
    UINT8   password[64];
    UINT8   pub_topic[128];
    UINT8   sub_topic[128];
    UINT8   pub_qos;
    UINT8   sub_qos;
    UINT8   client_id[32];
    UINT8   persistence;
    UINT8   will_topic[32];
    UINT8   will_msg[32];
    UINT16  keepalive;
    UINT8   reserved[8];          // 512 bytes
#elif defined (FEATURE_MQTT_MIB_V4)
    UINT8   server_ip[64];
    UINT16  port;
    UINT8   ssl;
    UINT8   user_name[64];
    UINT8   password[64];
    UINT8   pub_topic[64];
    UINT8   sub_topic[64];
    UINT8   pub_qos;
    UINT8   sub_qos;
    UINT8   client_id[32];
    UINT8   persistence;
    UINT8   will_topic[32];
    UINT8   will_msg[32];
    UINT16  keepalive;
    UINT8   reserved[1];          // 512 bytes
#endif    
} XTENSA_PACKED T_NMS_MQTT_MIB;
#endif /* FEATURE_MQTT_SUPP */

////////////////////////////////////////////////////////////////////////
// SNTP
#if defined (FEATURE_SNTP_SUPP)
typedef struct PACKED
{
    UINT8   ntp_addr1[32];
    UINT8   ntp_addr2[32];
    UINT8   ntp_addr3[32];
    INT16   gmt_offset;
} XTENSA_PACKED T_NMS_SNTP_MIB;
#endif /* FEATURE_SNTP_SUPP */

/*
******************************************************************************
*	GLOBAL VARIABLE
******************************************************************************
*/

/*
******************************************************************************
*	FUNCTIONS
******************************************************************************
*/



#endif /* HOST_STDA_APP_LIB */
#endif /* HOST_STDA_CM_INTERWORKING */
#endif /* __ICT_APP_COMMON_H__ */
