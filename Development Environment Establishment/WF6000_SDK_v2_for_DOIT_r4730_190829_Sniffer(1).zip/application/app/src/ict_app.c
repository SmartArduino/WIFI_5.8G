/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

#include "ict_app_globals.h"
#include "ict_cm_main.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

UINT8 sw_ver_info[30];

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

extern void ict_cm_task_initialization(void);

/* Don't insert any of functions on this place. 
     ict_app_task_initialization() is the first one on this file. */

/*****************************************************************************
** Function name: ict_app_task_initialization
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
void ict_app_task_initialization(void)   /* This function is placed on first address of IRAM1. */
{
    ICT_ST_FUNC_PTR_T st_func_ptr;
    UINT32 major_ver, minor_ver;
#if defined(FEATURE_FLASH_SHELL)
    UINT16 crc16_iram, crc16_dram, crc16_sf_code;
    BOOL   bank_valid;
#endif

    p_sw_ver_info = sw_ver_info;
    
    major_ver = SW_VER / 100;
    minor_ver = SW_VER % 100;

    ICT_SPRINTF((char*)p_sw_ver_info, "%02d.%02d.%s", major_ver, minor_ver, SW_VER_CM);

    /* Set Function Pointer */
    st_func_ptr.func_task_primitive_send = ict_app_task_primitive_send;
    st_func_ptr.func_task_event_send     = ict_app_task_event_send;
    ict_api_task_send_func_ptr_set(&st_func_ptr);
    
    ict_api_ext_hw_timer_start(APP_EXT_TIMER_1MS);
    
    /* Init CM Task */
    ict_cm_task_initialization();

    APP_PRINTF("%s [SW_VER=%s]\n", __func__, p_sw_ver_info);
#if defined (FEATURE_BOOTING_TIME_TUNING)
#else
#if defined(FEATURE_FLASH_SHELL)
    bank_valid = ict_api_flash_cmd_read_crc(SF_BANK_ID_1, &crc16_iram, &crc16_dram, &crc16_sf_code);
    APP_PRINTF("SF_Bank_1 Valid[%d] CRC[0x%02X 0x%02X 0x%02X]\n", bank_valid, crc16_iram, crc16_dram, crc16_sf_code);
    bank_valid = ict_api_flash_cmd_read_crc(SF_BANK_ID_2, &crc16_iram, &crc16_dram, &crc16_sf_code);
    APP_PRINTF("SF_Bank_2 Valid[%d] CRC[0x%02X 0x%02X 0x%02X]\n", bank_valid, crc16_iram, crc16_dram, crc16_sf_code);
#endif
#endif
}

/*****************************************************************************
** Function name: ict_app_task_primitive_send
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
INT32 ict_app_task_primitive_send(UINT8 network_id, UINT32 from, UINT32 to, UINT32 code, UINT32 length, UINT8 *p_buf)
{
    T_MAC_EVENT *p_event;
    void    *p_buffer;
    UINT8   err;

    p_event = (T_MAC_EVENT *)ict_api_task_allocate_primitive();

    if (p_event)
    {
        p_event->from       = from;
        p_event->to         = to;
        p_event->net_idx    = network_id;
        p_event->code       = code;
        p_event->len        = length;

        if (length > 0)
        {
            if (p_buf == ICT_NULL)
            {
                APP_PRINTF("[%s] Error\n", __func__);
                ict_api_task_free_primitive(p_event);
                //ICT_ASSERT(0);
                return ICT_FALSE;
            }

            p_buffer = ICT_MALLOC (length);

            if (p_buffer == ICT_NULL)
            {
                APP_PRINTF("[%s] %d->%d, %d/%d\n", __func__, from, to, code, length);
                ict_api_task_free_primitive(p_event);
                //ICT_ASSERT(0);
                return ICT_FALSE;
            }

            ICT_MEMCPY(p_buffer, p_buf, length);

            p_event->buf = p_buffer;
        }

        switch (to)
        {
            case TASK_ID_API_CM:
                ict_api_task_enqueue_primitive(&cm_primitive_queue, p_event);
                ict_api_os_flag_post(cm_event_group, EVENT_MASK_PRIMITIVE, OS_FLAG_SET, &err); /* uCOS feaure */
                break;

            default:
                APP_PRINTF("[%s] Error #1\n", __func__);
                ict_api_task_free_primitive(p_event);
                if (p_buffer)
                {
                    ICT_FREE (p_buffer);
                }
                //ICT_ASSERT(0);
                return ICT_FALSE;
                break;
        }
    }
    else
    {
        APP_PRINTF("[%s] Error #2\n", __func__);
        //ICT_ASSERT(0);
    }

    return ICT_TRUE;
}

/*****************************************************************************
** Function name: ict_app_task_event_send
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
INT32 ict_app_task_event_send(UINT32 to, UINT32 event)
{
    UINT8           err;
    
    if(event == 0)
    {
        return ICT_FALSE;
    }
    
    switch (to)
    {
        case TASK_ID_API_CM:
            ict_api_os_flag_post(cm_event_group, event, OS_FLAG_SET, &err); /* uCOS feaure */
            break;

        default:
            APP_PRINTF("[%s] Error #1\n" , __func__);
            //ICT_ASSERT(0);
            break;
    }

    return ICT_TRUE;
}
 

#endif /* HOST_STDA_CM_INTERWORKING */
