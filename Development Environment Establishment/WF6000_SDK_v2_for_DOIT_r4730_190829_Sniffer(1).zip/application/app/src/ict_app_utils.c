/*--------------------------------------------------------------------------
/	Project name	: I&C Tech Alphabeam WIFI
/	Copyright		: I&C Tech, All rights reserved.
/	File name		: ict_app_utils.c
/	Description		:
/
/	
/	
/	
/	Name		Date			Action
/	
---------------------------------------------------------------------------*/

#if defined(HOST_STDA_CM_INTERWORKING)

/*
******************************************************************************
*	INCLUDE
******************************************************************************
*/

#include "ict_app_globals.h"

/*
******************************************************************************
* 	LOCAL CONSTANTS
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL DATA TYPES
******************************************************************************
*/

/*
******************************************************************************
*	GLOBAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL VARIABLES
******************************************************************************
*/

/*
******************************************************************************
*	LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/

/*
******************************************************************************
*    FUNCTIONS
******************************************************************************
*/

/*****************************************************************************
** Function name: ict_app_get_token_ext
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
static UINT8 *ict_app_get_token_ext (UINT8 *p_in_str, UINT8 *p_out_token, UINT8 *sep, UINT32 token_size)
{
    UINT32 i,j;

    if (p_out_token)
    {
        //ICT_MEMSET(p_out_token, 0x00, token_size);
        p_out_token[0] = 0;
    }
    
    if (token_size < 2)
    {
        return ICT_NULL;
    }

    i = 0;
    j = 0;

    if (!p_in_str)
    {
        return ICT_NULL;
    }

    while (((p_in_str[i] == sep[0]) || (p_in_str[i] == sep[1]) || (p_in_str[i] == sep[2]) || (p_in_str[i] == sep[3]) || (p_in_str[i] == sep[4])) && (p_in_str[i] != NULL_STRING && p_in_str[i] != CARRIAGE_RETURN))
    {
        i++;
    }

    while ((p_in_str[i] != sep[0]) && (p_in_str[i] != sep[1]) && (p_in_str[i] != sep[2]) && (p_in_str[i] != sep[3]) && (p_in_str[i] != sep[4]) && (p_in_str[i] != NULL_STRING  && p_in_str[i] != CARRIAGE_RETURN))
    {
        p_out_token[j] = p_in_str[i];
        j++;
        i++;

        /* token size must be under token_size bytes */
        if (j >= (token_size-1))
        {
            goto ext;
        }        
    }

    while (((p_in_str[i] == sep[0]) || (p_in_str[i] == sep[1]) || (p_in_str[i] == sep[2]) || (p_in_str[i] == sep[3]) || (p_in_str[i] == sep[4])) && (p_in_str[i] != NULL_STRING && p_in_str[i] != CARRIAGE_RETURN))
    {
        i++;  
    }

ext:;
    p_out_token[j] = 0;

    return (&p_in_str[i]);
}  

/*****************************************************************************
** Function name: ict_app_get_token
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 *ict_app_get_token (UINT8 *p_in_str, UINT8 *p_out_token, UINT32 token_size)
{
    UINT8 sep[] = {' ', ',', '.', '=', '"'};
    
    return (ict_app_get_token_ext(p_in_str, p_out_token, sep, token_size));
}

/*****************************************************************************
** Function name: ict_app_get_token_2
** Descriptions:
** input parameters:
**
**
**
** output parameters:
** Returned value:
*****************************************************************************/
UINT8 *ict_app_get_token_2 (UINT8 *p_in_str, UINT8 *p_out_token, UINT32 token_size, UINT8 *sep)
{
    return (ict_app_get_token_ext(p_in_str, p_out_token, sep, token_size));
}

#endif /* HOST_STDA_CM_INTERWORKING */
